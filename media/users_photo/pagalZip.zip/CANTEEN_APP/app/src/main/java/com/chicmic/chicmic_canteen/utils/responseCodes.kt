package com.chicmic.chicmic_canteen.utils

class ResponseCodes {

    companion object {
        const val KEY_200 = 200
        const val KEY_401 = 401
        const val KEY_403 = 403
        const val KEY_500 = 500
        const val KEY_404 = 404
        const val KEY_400 = 400
    }

}