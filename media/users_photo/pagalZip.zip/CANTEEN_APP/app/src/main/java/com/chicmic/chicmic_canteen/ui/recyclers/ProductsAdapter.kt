package com.chicmic.chicmic_canteen.ui.recyclers

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.ItemProductBinding
import com.chicmic.chicmic_canteen.modals.dashboard.ProductModal
import com.chicmic.chicmic_canteen.utils.capitalizeSentences

class ProductsAdapter(private val array: ProductModal, private val listener: OnItemClickListener) :
    RecyclerView.Adapter<ProductsAdapter.ViewHolder>() {
    inner class ViewHolder(val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.itemOutOrNot.setOnClickListener {
                listener.onItemClickProduct(adapterPosition , ::updateData)
            }
        }

        private fun updateData() {
            array.result.data[adapterPosition].stock = !array.result.data[adapterPosition].stock
            notifyItemChanged(adapterPosition)
        }
    }


    interface OnItemClickListener {
        fun onItemClickProduct(position: Int , call : () -> Unit)
        fun notifyDataSetChangedProduct()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemProductBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return array.result.data.size
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            Glide.with(root.context)
                .load("${com.chicmic.chicmic_canteen.utils.Constants.BASE_URL}${array.result.data[position].image}")
                .placeholder(R.drawable.cancel)
                .into(categoryImage)
            categoryName.text = array.result.data[position].name.capitalizeSentences()

            if (array.result.data[position].stock) {
                itemOutOrNot.background =
                    ContextCompat.getDrawable(root.context, R.drawable.product_gray_background)
                itemOutOrNot.setTextColor(
                    ContextCompat.getColor(
                        root.context,
                        R.color.product_green
                    )
                )
                itemOutOrNot.text = root.context.getString(R.string.stock)
            } else {
                itemOutOrNot.background =
                    ContextCompat.getDrawable(root.context, R.drawable.product_green_background)
                itemOutOrNot.setTextColor(
                    ContextCompat.getColor(
                        root.context,
                        R.color.product_gray
                    )
                )
                itemOutOrNot.text = root.context.getString(R.string.stock_out)
            }

        }
    }


}