package com.chicmic.chicmic_canteen.ui.fragments.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.dashboard.DashBoardCategories
import com.chicmic.chicmic_canteen.modals.dashboard.LogoutResponse
import com.chicmic.chicmic_canteen.modals.dashboard.ProductModal
import com.chicmic.chicmic_canteen.modals.dashboard.StockToggleModal
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.Constants
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.launch

class DashBoardViewModal(application: Application) : AndroidViewModel(application) {

    companion object {
        private val sellerRepository = SellerRepository()
        private const val KEY_TAG = "DASHBOARD VIEW MODAL"
    }


    private val _categoryData: MutableLiveData<DashBoardCategories> = MutableLiveData()
    val categoryData: LiveData<DashBoardCategories> get() = _categoryData

    private val _cafeStatus: MutableLiveData<LogoutResponse> = MutableLiveData()
    val cafeStatus: LiveData<LogoutResponse> get() = _cafeStatus

    private val _productsData: MutableLiveData<ProductModal> = MutableLiveData()
    val productsData: LiveData<ProductModal> get() = _productsData

    private val _toggleProduct: MutableLiveData<StockToggleModal> = MutableLiveData()
    val toggleProduct: LiveData<StockToggleModal> get() = _toggleProduct

    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog

    fun getAllCategories() {

        viewModelScope.launch {
            try {
                val response = sellerRepository.getAllCategories()
                if (response.isSuccessful) {
                    if (response.body() is DashBoardCategories) {
                        val data = response.body() as DashBoardCategories
                        data.let {
                            _categoryData.postValue(it)
                        }
                    }
                } else {
                    responseCodes(responseCode = response.code())
                }
            } catch (e: Exception) {
                getException(e)
            }

        }
    }


        fun switchCafe( status: Int, function: () -> Unit) {
            viewModelScope.launch {
                try {

                    val response = sellerRepository.cafeSwitch(status)
                    if (response.isSuccessful) {
                        response.body()?.let {
                            _cafeStatus.postValue(it)
                        }
                    } else {
                        responseCodes(responseCode = response.code())
                    }
                } catch (e: java.lang.Exception) {
                    _showDialog.postValue(getException(e))
                }

            }
        }


        fun getAllProductsForACategory(
            id: Int,
            page: Int = Constants.KEY_INT_DEFAULT,
            search: String = Constants.KEY_STRING_DEFAULT
        ) {
            viewModelScope.launch {
                try {
                    val response = sellerRepository.getAllProductById(id, page, search)
                    if (response.isSuccessful) {
                        response.body()?.let {
                            _productsData.postValue(it)
                        }
                    } else {
                        responseCodes(responseCode = response.code())
                    }
                } catch (e: java.lang.Exception) {
                    _showDialog.postValue(getException(e))
                }
            }
        }


        fun toggleProduct(id: Int) {
            viewModelScope.launch {
                try {
                    val response = sellerRepository.toggleStock(id)
                    if (response.isSuccessful) {
                        response.body()?.let {
                            _toggleProduct.postValue(it)
                        }
                    } else {
                        responseCodes(responseCode = response.code())
                    }
                } catch (e: java.lang.Exception) {
                    _showDialog.postValue(getException(e))
                }
            }
        }


    private fun responseCodes(responseCode: Int) {
        when (responseCode) {
            ResponseCodes.KEY_200 -> _showDialog.postValue("false")
            ResponseCodes.KEY_401 -> _showDialog.postValue("true")
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_500 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )
        }
    }

}

