package com.chicmic.chicmic_canteen.ui.recyclers

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.ItemOrderBinding
import com.chicmic.chicmic_canteen.modals.dashboard.SubItems
import com.chicmic.chicmic_canteen.utils.capitalizeSentences

class SingleOrderItemAdapter(private val singleOrderList: ArrayList<SubItems>) :
    RecyclerView.Adapter<SingleItemViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SingleItemViewHolder {
        return SingleItemViewHolder(
            ItemOrderBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: SingleItemViewHolder, position: Int) {
        holder.binding.apply {
            Glide.with(root.context)
                .load("${com.chicmic.chicmic_canteen.utils.Constants.BASE_URL}${singleOrderList[position].product.image}")
                .placeholder(R.drawable.cancel)
                .into(ivItem)

            tvItemQuantity.text = StringBuilder(singleOrderList[position].quantity.toString())
                .append(" X ")
                .append(singleOrderList[position].product.name.capitalizeSentences())
        }
    }

    override fun getItemCount(): Int {
        return singleOrderList.size
    }
}

class SingleItemViewHolder(val binding: ItemOrderBinding) : RecyclerView.ViewHolder(binding.root) {

}