package com.chicmic.chicmic_canteen.ui.fragments.order

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.FragmentOrderDetailBinding
import com.chicmic.chicmic_canteen.ui.recyclers.SingleOrderItemAdapter
import com.chicmic.chicmic_canteen.utils.*


class OrderDetailFragment : Fragment() {

    private var _binding: FragmentOrderDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModal: OrderDetailViewModal
    private lateinit var sharedPreferencesManager: MySharedPreferencesManager
    private var token: String? = ""
    private val args: OrderDetailFragmentArgs by navArgs()
    private lateinit var adapter: SingleOrderItemAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOrderDetailBinding.inflate(inflater, container, false)
        initializeVariables()
        return binding.root
    }

    private fun initializeVariables() {
        viewModal = ViewModelProvider(this)[OrderDetailViewModal::class.java]
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(requireContext())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setClickListeners()
        setTheScreen()
        setTheAdapter()
        setObserver()
    }

    private fun setObserver() {
        viewModal.cancelOrder.observe(viewLifecycleOwner) {
            changeData()
            createDialog(requireContext(), getString(R.string.cancel_order_string))
        }
    }

    private fun changeData() {
        binding.apply {
            orderType.text = when (btnPrepared.text.toString()) {
                root.context.getString(R.string.preparing) -> {
                    root.context.getString(R.string.preparing)
                }
                root.context.getString(R.string.prepared) -> {
                    root.context.getString(R.string.prepared)
                }
                else -> {
                    root.context.getString(R.string.delivered)
                }
            }
            btnPrepared.text = when (btnPrepared.text.toString()) {
                root.context.getString(R.string.preparing) -> {
                    root.context.getString(R.string.prepared)
                }
                root.context.getString(R.string.prepared) -> {
                    root.context.getString(R.string.delivered)
                }
                else -> {
                    root.context.getString(R.string.delivered)
                }
            }
        }
    }

    private fun setTheAdapter() {
        binding.rlViewOrders.layoutManager = LinearLayoutManager(requireContext())
        adapter = SingleOrderItemAdapter(args.data.items)
        binding.rlViewOrders.adapter = adapter
        token = sharedPreferencesManager.getToken()
    }

    private fun setTheScreen() {
        binding.apply {
            "${args.data.user.firstName} ${args.data.user.lastName}".also {
                orderPersonName.text = it
            }
            "${args.data.user.userProfile?.empCode}".also { orderPersonId.text = it }
            orderTime.text = changeToRelevantFormat(args.data.createdAt, getString(R.string.date_string1))
            orderType.text = when (args.data.status) {
                Constants.NEW_ORDER_BIT.toInt() -> root.context.getString(R.string.new_order)
                Constants.PREPARING_ORDER_BIT.toInt() -> root.context.getString(R.string.preparing)
                Constants.PREPARED_ORDER_BIT.toInt() -> root.context.getString(R.string.prepared)
                Constants.CANCEL_ORDER_BIT.toInt() -> root.context.getString(R.string.canceled)
                Constants.DELIVERED_ORDER_BIT.toInt() -> root.context.getString(R.string.delivered)
                else -> root.context.getString(R.string.new_order)
            }.toString()

            btnPrepared.text = when (args.data.status) {
                Constants.NEW_ORDER_BIT.toInt() -> root.context.getString(R.string.preparing)
                Constants.PREPARING_ORDER_BIT.toInt() -> root.context.getString(R.string.prepared)
                Constants.PREPARED_ORDER_BIT.toInt() -> root.context.getString(R.string.delivered)
                else -> {
                    root.context.getString(R.string.delivered)
                }
            }

        }

    }

    private fun setClickListeners() {
        binding.apply {
            arrow.setOnClickListener {
                if(sharedPreferencesManager.getIsHistory()){
                    navigateToFragment(R.id.action_orderDetailFragment_to_historyFragment)
                }
            else
                {
                    navigateToFragment(R.id.action_orderDetailFragment_to_orderFragment)
                }

            }
            binding.btnPrepared.setOnClickListener {
                handlePreparedBtnClickListener()
            }
            binding.btnCanceled.setOnClickListener {
                handleCancelBtnClickListener()
            }
        }
    }

    private fun handleCancelBtnClickListener() {
            viewModal.cancelOrder( Constants.CANCEL_ORDER_BIT, args.data.id.toString())
    }

    private fun handlePreparedBtnClickListener() {
        binding.apply {
            when (btnPrepared.text.toString()) {
                root.context.getString(R.string.preparing) -> {
                    viewModal.cancelOrder(
                        Constants.PREPARING_ORDER_BIT,
                        args.data.id.toString()
                    )
                }
                root.context.getString(R.string.prepared) -> {
                    viewModal.cancelOrder(
                        Constants.PREPARED_ORDER_BIT,
                        args.data.id.toString()
                    )
                }
                else -> {
                    orderType.text = root.context.getString(R.string.delivered)
                    btnPrepared.text = root.context.getString(R.string.delivered_success)
                    createDialog(root.context , getString(R.string.order_delivered)
                    )
                }
            }
        }

    }




    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }


}