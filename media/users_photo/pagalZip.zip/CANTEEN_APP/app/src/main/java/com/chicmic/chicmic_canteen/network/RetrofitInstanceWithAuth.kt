package com.chicmic.chicmic_canteen.network

import android.content.Context
import android.util.Log
import com.chicmic.chicmic_canteen.utils.MyApp
import com.chicmic.chicmic_canteen.utils.MySharedPreferencesManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


class AuthInterceptor() : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = getTokenFromStorage()
        val request = chain.request()
        val newRequest = request.newBuilder()
            .addHeader("Authorization", token)
            .build()
        return chain.proceed(newRequest)
    }

    private fun getTokenFromStorage(): String {
        val sharedPreferences = MySharedPreferencesManager.getInstance(MyApp.getContext())
        return sharedPreferences.getToken() ?: ""
    }
}

class RetrofitInstanceWithAuth() {

    companion object {

        private const val BASE_URL = "http://192.180.2.134:8000/api/"
        private const val TIME_OUT_DURATION = 3L
    }

    private var interceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }


    private val authInterceptor = AuthInterceptor()
    private fun getClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(TIME_OUT_DURATION, TimeUnit.MINUTES)
            .writeTimeout(TIME_OUT_DURATION, TimeUnit.MINUTES)
            .readTimeout(TIME_OUT_DURATION, TimeUnit.MINUTES)
            .addInterceptor(authInterceptor)
            .addInterceptor(interceptor)
            .build()
    }


    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .client(getClient())
        .build()

    fun getApiService(): ApiCalls {
        return retrofit.create(ApiCalls::class.java)
    }
}
