package com.chicmic.chicmic_canteen.utils

class Constants {

    companion object {

        const val KEY_SPLASH_TIME = 5200L
        const val KEY_SHARED_PREFERENCE = "preferences"
        const val KEY_TOKEN = "token"
        const val KEY_USER_NAME = "user_name"
        const val KEY_USER_EMAIL = "user_email"
        const val KEY_USER_IMAGE = "user_image"
        const val KEY_DEVICE_TOKEN = "device_token"
        const val KEY_IS_HISTORY = "is_History"
        const val KEY_IS_CAFE_OPENED = "is_cafe_opened"
        const val KEY_WHICH_ORDER_CATEGORY = "which_category"
        const val KEY_WHICH_ORDER_CATEGORY_OLD = "which_category_old"
        const val KEY_STRING_DEFAULT = ""
        const val KEY_BOOLEAN_DEFAULT = true
        const val KEY_INT_DEFAULT = 1
        const val KEY_PASSWORD_PATTERN =
            "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+\$).{8,}\$"
        const val BASE_URL = "http://192.180.2.134:8000"
        const val NEW_ORDER_BIT = "1"
        const val CANCEL_ORDER_BIT = "5"
        const val PREPARING_ORDER_BIT = "2"
        const val PREPARED_ORDER_BIT = "3"
        const val DELIVERED_ORDER_BIT = "4"
        val FUNCTION_TO_BE_IMPLEMENTED: Nothing = TODO("Not yet implemented")
        const val NOTIFY_ID = 1002
        const val NAME = "Chicmic_Seller_APP"
        const val ID = "canteen_app"
        const val DESCRIPTION = "chicmic_seller_canteen_app"
        const val DEVICE_TYPE = 1
        const val FILE_PROVIDER = "com.chicmic.chicmic_canteen.provider"
        const val PACKAGE = "package"
        const val IMAGE_KEY = "image/*"
        const val KEY_SELECTED_IMAGE = "selected image"
        const val EMAIL_VALIDATION = "^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$"
        const val FORGOT_GUIDELINES =
            " 1 -> OTP will be Shared on Entered Email \n 2 -> Verify The OTP \n 3 -> Change Your Password "
        const val CLOSE_BUTTON_BIT = 0
        const val OPEN_BUTTON_BIT = 1
    }

}