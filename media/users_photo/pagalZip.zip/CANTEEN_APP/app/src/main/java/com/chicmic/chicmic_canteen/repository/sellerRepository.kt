package com.chicmic.chicmic_canteen.repository


import com.chicmic.chicmic_canteen.modals.ConfirmPasswordModal
import com.chicmic.chicmic_canteen.modals.ForgotPasswordModal
import com.chicmic.chicmic_canteen.modals.Login
import com.chicmic.chicmic_canteen.modals.OtpModal
import com.chicmic.chicmic_canteen.modals.dashboard.CancelOrder
import com.chicmic.chicmic_canteen.modals.dashboard.OpenCafeModal
import com.chicmic.chicmic_canteen.modals.dashboard.ResetPasswordModal
import com.chicmic.chicmic_canteen.network.ApiCalls
import com.chicmic.chicmic_canteen.network.ApiClient
import com.chicmic.chicmic_canteen.network.RetrofitInstanceWithAuth
import okhttp3.MultipartBody


class SellerRepository {


    private val apiService = ApiClient.create(ApiCalls::class.java)
    private val apiWithAuth  = RetrofitInstanceWithAuth().getApiService()
    suspend fun sellerLogin(data: Login) = apiService.login(data)

    suspend fun getOtpVerified(data : OtpModal) = apiService.verifyOtp(data)
    suspend fun getAllCategories() = apiWithAuth.getAllCategories()
    suspend fun logOutSeller() = apiWithAuth.logoutSeller()
    suspend fun cafeSwitch(status: Int) = apiWithAuth.cafeSwitch(
        OpenCafeModal(status)
    )
    suspend fun resetPassword(data: ResetPasswordModal) =
        apiWithAuth.resetPassword( data)
    suspend fun forgotPasswordShareMail(email: String) = apiService.forgotPasswordEmail(ForgotPasswordModal(email))
    suspend fun forgotPasswordChange(data: ConfirmPasswordModal) =
        apiService.forgotPasswordChange(data)
    suspend fun getAllProductById( id: Int , page : Int , search : String) = apiWithAuth.getProductList( id , page , search)
    suspend fun toggleStock( id: Int) = apiWithAuth.toggleStock(id)
    suspend fun getOrders( page: Int, status: Int, search: String ) =
        apiWithAuth.getOrders(page, status, search)
    suspend fun cancelOrders( status: String, id: String) =
        apiWithAuth.cancelOrder( CancelOrder(status), id.toInt())


    suspend fun updateProfile(body: MultipartBody) =
        apiWithAuth.profileUpdate( body)

}