package com.chicmic.chicmic_canteen.utils

import java.util.*

fun String.capitalizeSentences(): String {
    val sentences = split(". ")
    return sentences.joinToString(". ") { it.replaceFirstChar { char ->
        if (char.isLowerCase()) char.titlecase(
            Locale.ROOT
        ) else char.toString()
    } }
}