package com.chicmic.chicmic_canteen.utils





enum class ValidatorTypes{
    EMAIL , PASSWORD , OTP , CONFIRM_PASSWORD , NEW_PASSWORD
}

enum class OrderType(bit : Int){
     NEW_ORDER(1) , PREPARED_ORDER(2) , PREPARING_ORDER(3)
}

