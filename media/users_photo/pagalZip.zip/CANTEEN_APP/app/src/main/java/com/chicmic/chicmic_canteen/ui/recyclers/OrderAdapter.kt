package com.chicmic.chicmic_canteen.ui.recyclers

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.chicmic.chicmic_canteen.databinding.OrderDetailsBinding
import com.chicmic.chicmic_canteen.modals.dashboard.OrderItems
import com.chicmic.chicmic_canteen.utils.changeToRelevantFormat
import timber.log.Timber

class OrderAdapter(
    private val orderedItemList: ArrayList<OrderItems>,
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<OrderAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: OrderDetailsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.container.setOnClickListener {
                listener.onItemClick(position = adapterPosition)
            }
            binding.btnCancel.setOnClickListener {
                listener.cancelOrderItem(adapterPosition)
            }
            binding.btnPreparing.setOnClickListener {
                listener.prepareOrder(adapterPosition)
            }
            binding.btnPrepared.setOnClickListener {
                listener.preparedOrder(adapterPosition)
            }
            binding.btnDelivered.setOnClickListener {
                listener.deliveredOrder(adapterPosition)
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)
        fun notifyDataSetChanged()
        fun cancelOrderItem(position: Int)
        fun prepareOrder(position: Int)
        fun removeOrder(position: Int)
        fun deliveredOrder(position: Int)
        fun preparedOrder(position: Int)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            OrderDetailsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return orderedItemList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            "${orderedItemList[position].user.firstName}${orderedItemList[position].user.lastName} (${ orderedItemList[position].user.userProfile?.empCode?.let {
                formatCode(
                    it
                )
            } ?: "N/A"})".also {
                tvUsername.text = it
            }
            tvOrderTime.text = changeToRelevantFormat(orderedItemList[position].createdAt, "HH:mm")
            rlItems.adapter = SingleOrderItemAdapter(orderedItemList[position].items)
            when (orderedItemList[position].status) {
                1 -> visibilityOfBtn(
                    holder.binding,
                    visibility = true,
                    visibility1 = false,
                    visibility2 = false
                )
                2 -> visibilityOfBtn(
                    holder.binding,
                    visibility = false,
                    visibility1 = true,
                    visibility2 = false
                )
                3 -> visibilityOfBtn(
                    holder.binding,
                    visibility = false,
                    visibility1 = false,
                    visibility2 = true
                )
                else -> visibilityOfBtn(
                    holder.binding,
                    visibility = false,
                    visibility1 = false,
                    visibility2 = false
                )
            }
        }
    }

    private fun visibilityOfBtn(
        binding: OrderDetailsBinding,
        visibility: Boolean,
        visibility1: Boolean,
        visibility2: Boolean
    ) {
        binding.apply {
            btnLayoutOrder.isVisible = visibility
            btnPrepared.isVisible = visibility1
            btnDelivered.isVisible = visibility2
        }
    }

    private fun formatCode(code: String): String {
        return try {
            val lastIndex = code.lastIndexOf("/")
            code.substring(lastIndex+1, code.length)
        } catch (e: java.lang.Exception) {
            Timber.tag(javaClass.simpleName).e("$e")
            ""
        }
    }
}

