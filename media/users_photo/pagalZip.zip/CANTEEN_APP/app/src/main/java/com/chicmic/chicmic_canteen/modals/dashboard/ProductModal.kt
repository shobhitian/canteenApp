package com.chicmic.chicmic_canteen.modals.dashboard

import com.google.gson.annotations.SerializedName

data class ProductModal(
    val count : Int = 1 ,
    val next : String = "",
    val previous : Any? ="",
    @SerializedName("results")
    val result: Data = Data(ArrayList()),
    val message: String ="",
    @SerializedName("cafe_switch")
    val cafeSwitch : String ="",
    val status: Boolean = true,
    val response: String =""
)

data class Data(
    val data :  ArrayList<ProductDetail>,
)

data class ProductDetail(
    val id: Int,
    val name: String,
    val description: String ="",
    val image: String,
    val price: Int,
    val status: Boolean,
    var stock: Boolean,
)

data class StockToggleModal(
    val data: ProductDetail,
    val message: String,
    val status: Boolean,
    val response: String
)
