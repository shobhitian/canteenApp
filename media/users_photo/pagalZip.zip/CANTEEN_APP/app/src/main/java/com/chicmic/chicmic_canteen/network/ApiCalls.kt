package com.chicmic.chicmic_canteen.network

import com.chicmic.chicmic_canteen.modals.*
import com.chicmic.chicmic_canteen.modals.dashboard.*
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*

interface ApiCalls {

    /*  This api deals with LoginResponse */
    @POST("app/auth/login/")
    suspend fun login(@Body data: Login): Response<LoginResponse>

    @POST("app/auth/ConfirmPassword/")
    suspend fun verifyOtp( @Body data : OtpModal): Response<LogoutResponse>

    @GET("/api/app/categories/")
    suspend fun getAllCategories(): Response<DashBoardCategories>


    @POST("/categories/2/products/")
    suspend fun getAllProductsByCategory(@Query("id") id: Int): Response<DashBoardProductData>

    @POST("/toggle")
    suspend fun changeStatusOfProduct(@Query("id") id: Int): Response<String>

    @POST("app/auth/logout/")
    suspend fun logoutSeller(): Response<LogoutResponse>

    @Headers("Content-Type: application/json")
    @HTTP(method = "POST", path = "/api/app/cafeTime/", hasBody = true)
    suspend fun cafeSwitch(
        @Body data: OpenCafeModal
    ): Response<LogoutResponse>

    @POST("app/auth/resetpassword/")
    suspend fun resetPassword(
        @Body data: ResetPasswordModal
    ): Response<LogoutResponse>

    @HTTP(method = "POST", path = "app/auth/forgotpassword/", hasBody = true)
    suspend fun forgotPasswordEmail(@Body data: ForgotPasswordModal): Response<LogoutResponse>

    @HTTP(method = "POST", path = "app/auth/UpdatePassword/", hasBody = true)
    suspend fun forgotPasswordChange(@Body data: ConfirmPasswordModal): Response<LogoutResponse>

    @GET("app/getProductViaCat")
    suspend fun getProductList(
        @Query("category_id") id: Int,
        @Query("page") page: Int,
        @Query("search") search : String
    ): Response<ProductModal>

    @PUT("app/productStock/{id}/")
    suspend fun toggleStock(
        @Path("id") id: Int
    ): Response<StockToggleModal>


    @GET("app/sellerOrder/")
    suspend fun getOrders(
        @Query("page") page: Int,
        @Query("status") status: Int,
        @Query("name") name: String,
    ): Response<OrderModal>


    @HTTP(method = "PUT", path = "app/sellerOrder/{id}/", hasBody = true)
    suspend fun cancelOrder(
        @Body status: CancelOrder,
        @Path("id") id: Int
    ): Response<LogoutResponse>


    @Multipart
    @POST("app/auth/ManageProfile/")
    suspend fun profileUpdate(
        @Part filePart: MultipartBody,
    ): Response<UserImageResponse>


}