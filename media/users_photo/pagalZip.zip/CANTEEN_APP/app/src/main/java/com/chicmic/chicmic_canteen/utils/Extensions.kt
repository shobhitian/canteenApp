package com.chicmic.chicmic_canteen.utils


import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController


fun Fragment.navigateToFragment( action : Int){
    findNavController().navigate(action)
}

