package com.chicmic.chicmic_canteen.utils


import android.text.Editable
import android.text.TextWatcher
import com.chicmic.chicmic_canteen.modals.dashboard.DashBoardCategories
import com.chicmic.chicmic_canteen.modals.dashboard.OrderItems
import com.chicmic.chicmic_canteen.modals.dashboard.OrderModal
import com.chicmic.chicmic_canteen.modals.dashboard.ProductModal

interface SearchResultInterFace {
    fun onSearchResult(array: DashBoardCategories, i: Int)
    fun onSearchResultProducts(array: ProductModal, i: Int)
    fun onSearchResultOrders(array: ArrayList<OrderModal>, i: Int)
}


class SearchManager(
    private val listener: SearchResultInterFace,
    private val array: Any,
) : TextWatcher {

    companion object {
        private var filteredArray: DashBoardCategories =
            DashBoardCategories(ArrayList(), "", true, "")
        private var filteredArrayProducts: ProductModal = ProductModal()
        private var filteredArrayOrders: OrderItems? = null
        private var filteredArrayOrderReturn: ArrayList<OrderModal>? = null
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

    override fun afterTextChanged(s: Editable?) {
        filteredArrayProducts.result.data.clear()
        filteredArray.data.clear()
        if (array is DashBoardCategories) {
            if (s?.isEmpty() == true) {
                filteredArray.data.clear()
                listener.onSearchResult(filteredArray, 1)
            } else {
                for (i in array.data) {
                    if (s?.let { i.name.contains(it, ignoreCase = true) } == true) {
                        if (!filteredArray.data.contains(i))
                            filteredArray.data.add(i)
                    }
                }
                listener.onSearchResult(filteredArray, 2)
            }
        } else if (array is ProductModal) {

            if (s?.isEmpty() == true) {
                filteredArrayProducts.result.data.clear()
                listener.onSearchResultProducts(filteredArrayProducts, 1)
            } else {
                for (i in array.result.data) {
                    if (s?.let { i.name.contains(it, ignoreCase = true) } == true) {
                        if (!filteredArrayProducts.result.data.contains(i))
                            filteredArrayProducts.result.data.add(i)
                    }
                }
                listener.onSearchResultProducts(filteredArrayProducts, 2)
            }
        } else if (array is OrderModal) {
            if (s?.isEmpty() == true) {
                filteredArrayOrders?.items?.clear()
                if(filteredArrayOrderReturn != null)
                filteredArrayOrders?.let { listener.onSearchResultOrders(filteredArrayOrderReturn!!, 1) }
            } else {
                for ((i, position) in array.data) {
                    if (s?.let { i.firstName.contains(it, ignoreCase = true) } == true) {
                        if (!filteredArrayOrders?.user?.firstName?.contains(
                                i.firstName,
                                true
                            )!!
                        ) {
                            filteredArrayOrderReturn?.add(
                                OrderModal(
                                    array.count,
                                    array.data,
                                    array.message,
                                    array.status,
                                    array.response
                                )
                            )
                        }
                    }
                }
                if(filteredArrayOrderReturn != null)
                 listener.onSearchResultOrders(filteredArrayOrderReturn!!, 2)
            }
        }
    }
}
