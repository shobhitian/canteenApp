package com.chicmic.chicmic_canteen.ui.fragments.forgot

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.FragmentForgotPasswordBinding
import com.chicmic.chicmic_canteen.modals.ConfirmPasswordModal
import com.chicmic.chicmic_canteen.modals.OtpModal
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.chicmic.chicmic_canteen.utils.*
import com.google.android.material.textfield.TextInputLayout

class ForgotPassword : Fragment(), ValidateResultInterface {


    private var _binding: FragmentForgotPasswordBinding? = null
    private val binding get() = _binding!!
    private var flag = 1
    private var isTimeDone = true
    private lateinit var viewModal: ForgotPasswordViewModal

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentForgotPasswordBinding.inflate(inflater, container, false)
        initializeVariables()
        return binding.root
    }

    private fun initializeVariables() {
        viewModal = ViewModelProvider(this)[ForgotPasswordViewModal::class.java]
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        showUserInstructions()
        setClickListeners()
        setListeners()
        setObserver()
    }

    private fun setObserver() {
        viewModal.forgotEmailResponse.observe(viewLifecycleOwner) {
            if (it.status.toBoolean()) {
                createDialog(requireContext(), getString(R.string.email_sent))
                afterEmailShare()
                flag = 2
            }
        }

        viewModal.forgotChangeResponse.observe(viewLifecycleOwner) {
            if (it.status.toBoolean()) {
                flag = 1
                showConfirmationDialog(
                    requireContext(),
                    it.message,
                    getString(R.string.login_go),
                    "",
                    ::navigateToLogin
                )

            }
        }

        viewModal.forgotOTPResponse.observe(viewLifecycleOwner) {
            binding.apply {
                flag = 3
                disabledButton(true)
                submitButton.text = getString(R.string.change_password)
                etForgotOtp.isEnabled = false
                resendBtnLayout.visibility = View.GONE
                etForgotPassword.isEnabled = true
                forgotPassword.isEnabled = true
                forgotConfirmPassword.isEnabled = true
                etForgotConfirmPassword.isEnabled = true
                createDialog(requireContext(), it.message)
            }

        }
        viewModal.showDialog.observe(viewLifecycleOwner) {
            createDialog(requireContext(), it)
            disabledButton(true)
        }
    }

    private fun afterEmailShare() {
        binding.apply {
            disabledFieldAfterEmailVerification(true)
            disabledButton(true)
            binding.submitButton.text = requireContext().getString(R.string.verify_otp)
            forgotEmail.isEnabled = false
            resendBtn.isVisible = true
            resendBtn.isEnabled = true
        }
    }

    private fun showUserInstructions() {
        activity?.let {
            removeActionBar(it, requireContext())
            changeTopBarColor(requireContext(), (activity as MainActivity).window, R.color.white)
        }
        createDialog(
            requireContext(),
            Constants.FORGOT_GUIDELINES,
            getString(R.string.forgot_password_quidelines)
        )
    }

    private fun setListeners() {
        binding.etForgotEmail.addTextChangedListener(
            ValidationTextWatcher(
                Constants.EMAIL_VALIDATION,
                this@ForgotPassword,
                binding.forgotEmail,
                ValidatorTypes.EMAIL
            )
        )

        binding.etForgotOtp.addTextChangedListener(
            ValidationTextWatcher(
                "",
                this@ForgotPassword,
                binding.otp,
                ValidatorTypes.OTP
            )
        )

        binding.etForgotPassword.addTextChangedListener(
            ValidationTextWatcher(
                "",
                this@ForgotPassword,
                binding.forgotPassword,
                ValidatorTypes.PASSWORD
            )
        )
        binding.etForgotConfirmPassword.addTextChangedListener(
            ValidationTextWatcher(
                "",
                this@ForgotPassword,
                binding.forgotConfirmPassword,
                ValidatorTypes.CONFIRM_PASSWORD
            )
        )

    }

    private fun setClickListeners() {
        binding.apply {
            arrow.setOnClickListener {
                navigateToLogin()
            }
            submitButton.setOnClickListener {
                submitButtonHandler()
            }
            resendBtn.setOnClickListener {
                resendButtonHandler()
            }
        }
    }

    private fun navigateToLogin() {
        timer.cancel()
        navigateToFragment(R.id.action_forgotPassword2_to_loginFragment)
    }

    private val timer = object : CountDownTimer(60000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            val seconds = millisUntilFinished / 1000
            binding.resendTimer.text = seconds.toString()
        }

        override fun onFinish() {
            binding.resendTimer.visibility = View.GONE
            binding.resendBtn.isEnabled = true
            binding.resendBtn.text = getString(R.string.resendOtp)
            isTimeDone = true

        }
    }

    private fun resendButtonHandler() {
        if (isTimeDone) {
            isTimeDone = false
            viewModal.forgotEmail(binding.etForgotEmail.text.toString())
        } else {
            createDialog(requireContext(), getString(R.string.wait_remain))
        }
        binding.resendTimer.visibility = View.VISIBLE
        binding.resendBtn.isEnabled = false
        binding.resendBtn.text = getString(R.string.wait_for_60)
        timer.start()
    }

    private fun submitButtonHandler() {
        binding.apply {
            disabledButton(false)
            if (flag == 1) {
                if (validateEmail() == true) {
                    viewModal.forgotEmail(etForgotEmail.text.toString())
                } else {
                    disabledButton(true)
                    createDialog(requireContext(), getString(R.string.email_check))
                }
            } else if (flag == 2) {
                if (binding.etForgotOtp.text?.trim()?.length!! !=  6) {
                    disabledButton(true)
                    createDialog(
                        requireContext(),
                        getString(R.string.otp_validation)
                    )
                } else {
                    viewModal.getOtpVerified(
                        OtpModal(
                            binding.etForgotOtp.text.toString(),
                            binding.etForgotEmail.text.toString()
                        )
                    )

                }
            } else {
                if (validateData()) {
                    viewModal.forgotPasswordChange(
                        ConfirmPasswordModal(
                            etForgotConfirmPassword.text.toString(),
                            etForgotEmail.text.toString()
                        )
                    )
                } else {
                    disabledButton(true)
                    createDialog(
                        requireContext(),
                        getString(R.string.password_check)
                    )
                }

            }
        }
    }

    private fun disabledFieldAfterEmailVerification(visibility: Boolean) {
        binding.apply {
            otp.isEnabled = visibility
        }

    }


    private fun validateEmail(): Boolean? {
        val result = binding.etForgotEmail.text?.let {
            Patterns.EMAIL_ADDRESS.matcher(it).matches()
        }
        return result
    }

    private fun disabledButton(flag: Boolean) {
        binding.submitButton.isEnabled = flag
    }

    private fun validateData(): Boolean {
        return when {
            binding.etForgotConfirmPassword.text?.toString()
                ?.matches(Constants.KEY_PASSWORD_PATTERN.toRegex()) != true -> false
            binding.etForgotPassword.text.toString() != binding.etForgotConfirmPassword.text.toString() -> false
            else -> true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    override fun onValidationResult(isValid: Boolean, loginEmail: TextInputLayout) {
        if (isValid) {
            loginEmail.setBackgroundResource(R.drawable.login_fields_background)
        } else {
            loginEmail.setBackgroundResource(R.drawable.login_background_error)
        }
    }

}