package com.chicmic.chicmic_canteen.ui.fragments.order

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.dashboard.LogoutResponse
import com.chicmic.chicmic_canteen.modals.dashboard.OrderModal
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.launch

class OrderViewModal(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "ORDER_VIEW_MODAL"
        private val sellerRepository = SellerRepository()
    }

    private val _orderData: MutableLiveData<OrderModal> = MutableLiveData()
    val orderData: LiveData<OrderModal> get() = _orderData

    private val _cafeStatus: MutableLiveData<LogoutResponse> = MutableLiveData()
    val cafeStatus: LiveData<LogoutResponse> get() = _cafeStatus

    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog

    private val _cancelOrder: MutableLiveData<LogoutResponse> = MutableLiveData()
    val cancelOrder: LiveData<LogoutResponse> get() = _cancelOrder

    fun getOrders( page: Int, status: Int, search: String) {
        viewModelScope.launch {
            try {
                val response =
                    search.let { sellerRepository.getOrders( page, status, it) }
                if (response.isSuccessful) {
                    response.body()?.let {
                        _orderData.postValue(it)
                    }
                } else
                    responseCodes(response.code())
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }


    fun switchCafe( status: Int, function: () -> Unit) {
        viewModelScope.launch {
            try {
                val response = sellerRepository.cafeSwitch(status)
                if (response.isSuccessful) {
                    response.body()?.let {
                        _cafeStatus.postValue(it)
                        function()
                    }
                } else {
                    responseCodes(responseCode = response.code())
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }

    fun cancelOrder( status: String, id: String, function: () -> Unit) {
        viewModelScope.launch {
            try {
                val response = sellerRepository.cancelOrders( status, id)
                if (response.isSuccessful) {
                    response.body()?.let {
                        _cancelOrder.postValue(it)
                        function()
                    }
                } else
                    responseCodes(response.code())
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }


    private fun responseCodes(responseCode: Int) {
        when (responseCode) {

            ResponseCodes.KEY_401 ->{
                _showDialog.postValue("true")
            }
            ResponseCodes.KEY_400, ResponseCodes.KEY_500 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            )
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )
            else -> {
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            }

        }
    }

}