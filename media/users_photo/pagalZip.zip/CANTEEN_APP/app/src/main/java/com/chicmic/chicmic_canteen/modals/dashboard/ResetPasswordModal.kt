package com.chicmic.chicmic_canteen.modals.dashboard

data class ResetPasswordModal(
    val old_password: String,
    val new_password: String
)
