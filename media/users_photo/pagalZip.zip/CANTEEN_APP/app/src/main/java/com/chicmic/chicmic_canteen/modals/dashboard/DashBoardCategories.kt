package com.chicmic.chicmic_canteen.modals.dashboard

import com.google.gson.annotations.SerializedName

data class DashBoardCategories(
    val data: ArrayList<Categories> = ArrayList(),
    val message: String ="",
    val status: Boolean =true,
    val response: String = ""
)

data class Categories(
    val id: Int,
    val name: String,
    val image: String,
    var status: Boolean,
    @SerializedName("ref_user")
    val refUser: Int,
    var selection : Boolean = true
)


data class DashBoardProductData(
    val data: ArrayList<ProductData>,
    val message: String,
    val status: String,
    val response: String
)

data class DashBoardProductDataForRecycler(
    val data: ArrayList<ProductData>
)

data class ProductData(
    val id: Int,
    val name: String,
    val description: String,
    val image: String,
    val price: Int,
    val status: String,
    val stock: String,
    val availability: String,
    val category: String,
    @SerializedName("ref_user")
    val refUser: String,

    )


