package com.chicmic.chicmic_canteen.ui.fragments.order

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.dashboard.LogoutResponse
import com.chicmic.chicmic_canteen.modals.dashboard.OrderModal
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.launch

class OrderDetailViewModal(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "ORDER_DETAIL_VIEW_MODAL"
        private val sellerRepository = SellerRepository()
    }

    private val _cancelOrder: MutableLiveData<LogoutResponse> = MutableLiveData()
    val cancelOrder: LiveData<LogoutResponse> get() = _cancelOrder


    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog

    fun cancelOrder( status: String, id: String) {

            viewModelScope.launch {
                try {
                    val response = sellerRepository.cancelOrders(status, id)
                    if (response.isSuccessful) {
                        response.body()?.let {
                            _cancelOrder.postValue(it)
                        }
                    } else
                        responseCodes(response.code())
                } catch (e: java.lang.Exception) {
                    _showDialog.postValue(getException(e))
                }
            }
    }




    private fun responseCodes(responseCode: Int) {
        when (responseCode) {
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_500  , ResponseCodes.KEY_400 , ResponseCodes.KEY_401 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )
        }
    }


}