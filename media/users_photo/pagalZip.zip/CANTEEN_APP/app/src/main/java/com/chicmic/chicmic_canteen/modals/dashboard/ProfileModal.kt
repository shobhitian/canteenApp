package com.chicmic.chicmic_canteen.modals.dashboard


data class LogoutResponse(
    val message: String,
    val status: String,
    val response: String,


    )