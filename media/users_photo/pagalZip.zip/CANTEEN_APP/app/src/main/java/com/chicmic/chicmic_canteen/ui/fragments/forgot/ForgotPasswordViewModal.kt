package com.chicmic.chicmic_canteen.ui.fragments.forgot


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.ConfirmPasswordModal
import com.chicmic.chicmic_canteen.modals.OtpModal
import com.chicmic.chicmic_canteen.modals.dashboard.LogoutResponse
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.launch


class ForgotPasswordViewModal(application: Application) : AndroidViewModel(application) {


    companion object {
        private const val TAG = "FORGOT_PASSWORD_VIEW_MODAL"
        private val sellerRepository = SellerRepository()
    }


    private val _forgotEmailResponse: MutableLiveData<LogoutResponse> = MutableLiveData()
    val forgotEmailResponse: LiveData<LogoutResponse> get() = _forgotEmailResponse

    private val _forgotOTPResponse: MutableLiveData<LogoutResponse> = MutableLiveData()
    val forgotOTPResponse: LiveData<LogoutResponse> get() = _forgotOTPResponse

    private val _forgotChangeResponse: MutableLiveData<LogoutResponse> = MutableLiveData()
    val forgotChangeResponse: LiveData<LogoutResponse> get() = _forgotChangeResponse

    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog


    fun forgotEmail(email: String) {
        viewModelScope.launch {
            try {
                val response = sellerRepository.forgotPasswordShareMail(email)
                if (response.isSuccessful)
                    response.body()?.let {
                        _forgotEmailResponse.postValue(it)
                    } else {
                    showResponse(response.code())
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }

        }
    }

    fun getOtpVerified(data: OtpModal) {
        viewModelScope.launch {
            try {
                val response = sellerRepository.getOtpVerified(data)
                if (response.isSuccessful)
                    response.body()?.let {
                        _forgotOTPResponse.postValue(it)
                    } else {
                    showResponse(response.code())
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }

    fun forgotPasswordChange(data: ConfirmPasswordModal) {
        viewModelScope.launch {
            try {
                val response = sellerRepository.forgotPasswordChange(data)
                if (response.isSuccessful)
                    response.body()?.let {
                        _forgotChangeResponse.postValue(it)
                    } else {
                    showResponse(response.code())
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }


    private fun showResponse(code: Int) {
        when (code) {
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_400 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.invalid_otp
                )
            )
            ResponseCodes.KEY_500 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )

        }
    }
}
