package com.chicmic.chicmic_canteen.utils

import android.text.Editable
import android.text.TextWatcher
import com.google.android.material.textfield.TextInputLayout
import java.util.regex.Pattern

interface ValidateResultInterface {
    fun onValidationResult(isValid: Boolean, loginEmail: TextInputLayout)
}


class ValidationTextWatcher(
    private val pattern: String,
    private val listener: ValidateResultInterface,
    private val whichLayout: TextInputLayout,
    private val type: ValidatorTypes,

    ) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

    override fun afterTextChanged(s: Editable?) {

        when (type) {
            ValidatorTypes.EMAIL -> {
                val valid = if (s?.isEmpty() == true) true
                else s?.matches(Regex(pattern)) ?: true
                listener.onValidationResult(valid, whichLayout)
            }
            ValidatorTypes.OTP -> {
                val valid = if (s?.isEmpty() == true) true
                else s?.length == 6
                listener.onValidationResult(valid, whichLayout)
            }
            ValidatorTypes.CONFIRM_PASSWORD , ValidatorTypes.PASSWORD -> {
                try {
                    val valid = if (s?.isEmpty() == true) true
                    else s?.length!! >=  6
                    listener.onValidationResult(valid, whichLayout)
                } catch (e: Exception) {
                    listener.onValidationResult(true , whichLayout)
                }
            }
            ValidatorTypes.NEW_PASSWORD  -> {
                try {
                    val valid = if (s?.isEmpty() == true) true
                    else s?.matches(Regex(pattern)) ?: true
                    listener.onValidationResult(valid, whichLayout)
                } catch (e: Exception) {
                    listener.onValidationResult(true , whichLayout)
                }
            }
        }

    }
}
