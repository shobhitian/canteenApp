package com.chicmic.chicmic_canteen.utils

import android.content.Context
import android.content.SharedPreferences

class MySharedPreferencesManager private constructor(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(Constants.KEY_SHARED_PREFERENCE, Context.MODE_PRIVATE)

    companion object {
        @Volatile
        private var INSTANCE: MySharedPreferencesManager? = null

        fun getInstance(context: Context): MySharedPreferencesManager =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: MySharedPreferencesManager(context).also { INSTANCE = it }
            }
    }


    /* These methods are for storing and getting the Authorization token */
    fun saveToken(key: String) {
        sharedPreferences.edit().putString(Constants.KEY_TOKEN, key).apply()
    }

    fun getToken(): String? {
        return sharedPreferences.getString(Constants.KEY_TOKEN, Constants.KEY_STRING_DEFAULT)
    }

    /* this is to check that whether the cafe is closed or opened*/
    fun saveIsCafeOpened(key: Boolean) {
        sharedPreferences.edit().putBoolean(Constants.KEY_IS_CAFE_OPENED, key).apply()

    }

    fun getIsCafeOpened(): Boolean {
        return sharedPreferences.getBoolean(
            Constants.KEY_IS_CAFE_OPENED,
            Constants.KEY_BOOLEAN_DEFAULT,

            )
    }


    fun findWhichOrderCategory(key: Int) {
        sharedPreferences.edit().putInt(Constants.KEY_WHICH_ORDER_CATEGORY, key).apply()


    }

    fun getWhichOrderCategory(): Int {
        return sharedPreferences.getInt(
            Constants.KEY_WHICH_ORDER_CATEGORY,
            Constants.KEY_INT_DEFAULT,
            )
    }

    fun getWhichOrderCategoryOld(): Int {
        return sharedPreferences.getInt(
            Constants.KEY_WHICH_ORDER_CATEGORY_OLD,
            Constants.KEY_INT_DEFAULT,

            )
    }
    /*  storing the user data */
    fun saveUserName(key: String) {
        sharedPreferences.edit().putString(Constants.KEY_USER_NAME, key).apply()
    }

    fun getUserName(): String? {
        return sharedPreferences.getString(Constants.KEY_USER_NAME, Constants.KEY_STRING_DEFAULT)
    }

    fun saveUserEmail(key: String) {
        sharedPreferences.edit().putString(Constants.KEY_USER_EMAIL, key).apply()
    }

    fun getUserEmail(): String? {
        return sharedPreferences.getString(Constants.KEY_USER_EMAIL, Constants.KEY_STRING_DEFAULT)
    }

    fun saveUserImage(key: String) {
        sharedPreferences.edit().putString(Constants.KEY_USER_IMAGE, key).apply()
    }

    fun saveUserSelectedImage(key:String){
        sharedPreferences.edit().putString(Constants.KEY_SELECTED_IMAGE,key).apply()
    }

    fun getUserSelectedImage():String?{
        return sharedPreferences.getString(Constants.KEY_SELECTED_IMAGE, Constants.KEY_STRING_DEFAULT)
    }

    fun getUserImage(): String? {
        return sharedPreferences.getString(Constants.KEY_USER_IMAGE, Constants.KEY_STRING_DEFAULT)
    }

    fun saveUserDeviceToken(key: String) {
        sharedPreferences.edit().putString(Constants.KEY_DEVICE_TOKEN, key).apply()
    }

    fun getUserDeviceToken(): String? {
        return sharedPreferences.getString(Constants.KEY_DEVICE_TOKEN, Constants.KEY_STRING_DEFAULT)
    }

    fun saveIsHistory(key: Boolean) {
        sharedPreferences.edit().putBoolean(Constants.KEY_IS_HISTORY, key).apply()
    }
    fun getIsHistory() : Boolean {
        return sharedPreferences.getBoolean(Constants.KEY_IS_HISTORY, Constants.KEY_BOOLEAN_DEFAULT)
    }

}