package com.chicmic.chicmic_canteen.ui.fragments.reset


import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.FragmentResetPasswordBinding
import com.chicmic.chicmic_canteen.modals.dashboard.ResetPasswordModal
import com.chicmic.chicmic_canteen.utils.*
import com.google.android.material.textfield.TextInputLayout


class ResetPasswordFragment(private val enableButton: () -> Unit) : DialogFragment(),
    ValidateResultInterface {


    private lateinit var viewModal: ResetPasswordViewModal
    private lateinit var binding: FragmentResetPasswordBinding
    private lateinit var sharedPreferencesManager: MySharedPreferencesManager


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentResetPasswordBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeVariables()
        initializeClickListeners()
        initializeListeners()
        initializeObservers()
        dialog?.setCancelable(false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog_background)

    }


    private fun initializeVariables() {
        viewModal = ViewModelProvider(this)[ResetPasswordViewModal::class.java]
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(requireContext())
    }



    private fun initializeObservers() {
        binding.apply {
            viewModal.resetPassword.observe(viewLifecycleOwner) {
                resetPasswordButton1.isEnabled = true
                createDialog(requireContext(), it.message)
                etNewPassword.setText("")
                etOldPassword.setText("")
                etConfirmPassword.setText("")
                progress.visibility = View.GONE
                dialog?.dismiss()
                enableButton
            }
            viewModal.showDialog.observe(viewLifecycleOwner) {
                enableButton
                createDialog(requireContext(), it)
                resetPasswordButton1.isEnabled = true
                progress.visibility = View.GONE
            }
        }
    }

    private fun initializeListeners() {
        binding.apply {
            etOldPassword.addTextChangedListener(
                ValidationTextWatcher(
                    Constants.KEY_PASSWORD_PATTERN,
                    this@ResetPasswordFragment,
                    oldPassword,
                    ValidatorTypes.PASSWORD
                )
            )
            etNewPassword.addTextChangedListener(
                ValidationTextWatcher(
                    Constants.KEY_PASSWORD_PATTERN,
                    this@ResetPasswordFragment,
                    newPassword,
                    ValidatorTypes.NEW_PASSWORD
                )
            )

            etConfirmPassword.addTextChangedListener(
                ValidationTextWatcher(
                    Constants.KEY_PASSWORD_PATTERN,
                    this@ResetPasswordFragment,
                    confirmPassword,
                    ValidatorTypes.NEW_PASSWORD
                )
            )
        }
    }

    private fun initializeClickListeners() {
        binding.apply {
            resetPasswordButton1.setOnClickListener {
                submitButtonHandler()
            }

            cancelButtonReset.setOnClickListener {
                dialog?.dismiss()
                enableButton()
            }
        }
    }

    private fun submitButtonHandler() {
        binding.apply {
            resetPasswordButton1.isEnabled = false
            if (validateData()) {
                progress.visibility = View.VISIBLE
                viewModal.changePassword(
                    ResetPasswordModal(
                        etOldPassword.text.toString(),
                        etConfirmPassword.text.toString()
                    )
                )
            } else {
                resetPasswordButton1.isEnabled = true
                createDialog(
                    requireContext(),
                    getString(R.string.password_error),
                    getString(R.string.fill_all_field)
                )
            }
        }
    }

    private fun validateData(): Boolean {
        binding.apply {
            return when {
                etOldPassword.text?.isEmpty() == true -> false
                etNewPassword.text?.toString()
                    ?.matches(Constants.KEY_PASSWORD_PATTERN.toRegex()) != true -> false
                etNewPassword.text.toString() != etConfirmPassword.text.toString() -> false
                else -> true
            }
        }
    }

    override fun onValidationResult(isValid: Boolean, loginEmail: TextInputLayout) {
        if (isValid) {
            loginEmail.setBackgroundResource(R.drawable.login_fields_background)
        } else {
            loginEmail.setBackgroundResource(R.drawable.login_background_error)
        }
    }
}