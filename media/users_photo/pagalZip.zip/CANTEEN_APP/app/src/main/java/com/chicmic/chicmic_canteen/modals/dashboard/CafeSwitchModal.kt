package com.chicmic.chicmic_canteen.modals.dashboard

data class CafeData(

    val id: Int,
    val startTime: String,
    val endTime: String,
    val is_open: Boolean,
)

data class CafeSwitchModal(
    val data: CafeData,
    val message: String,
    val status: Boolean,
    val response: String


)

data class OpenCafeModal(
    val status: Int,
)