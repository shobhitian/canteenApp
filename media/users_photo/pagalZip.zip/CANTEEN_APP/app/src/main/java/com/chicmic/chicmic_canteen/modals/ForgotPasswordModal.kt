package com.chicmic.chicmic_canteen.modals

data class ForgotPasswordModal(
    val email: String,
)

data class ConfirmPasswordModal(
    val password: String,
    val email: String
)

data class OtpModal(
    val otp: String,
    val email: String,

    )