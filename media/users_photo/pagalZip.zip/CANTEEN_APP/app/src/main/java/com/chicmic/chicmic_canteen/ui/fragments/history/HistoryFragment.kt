package com.chicmic.chicmic_canteen.ui.fragments.history

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.FragmentHistoryBinding
import com.chicmic.chicmic_canteen.modals.dashboard.DashBoardCategories
import com.chicmic.chicmic_canteen.modals.dashboard.OrderItems
import com.chicmic.chicmic_canteen.modals.dashboard.OrderModal
import com.chicmic.chicmic_canteen.modals.dashboard.ProductModal
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.chicmic.chicmic_canteen.ui.fragments.order.OrderViewModal
import com.chicmic.chicmic_canteen.ui.recyclers.OrderAdapter
import com.chicmic.chicmic_canteen.utils.*

class HistoryFragment : Fragment(), OrderAdapter.OnItemClickListener, SearchResultInterFace {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModal: OrderViewModal
    private lateinit var sharedPreferencesManager: MySharedPreferencesManager
    private lateinit var adapter: OrderAdapter
    private var itemPosition: Int? = 0
    private var totalOrderCount: Int? = 0
    private var page = 1
    private lateinit var lateData : ArrayList<OrderItems>
    private lateinit var orderArray: ArrayList<OrderItems>
    private lateinit var storeArray: ArrayList<OrderItems>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        initializeVariables()
        screenSetup()
        return binding.root
    }

    private fun screenSetup() {
        if (activity != null) {
            (activity as MainActivity).apply {
                supportActionBar?.hide()
                setBottomVisibility(true)
                changeTopBarColor(requireContext(), window, R.color.white)
            }
        }
    }

    private fun initializeVariables() {
        viewModal = ViewModelProvider(this)[OrderViewModal::class.java]
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(requireContext())
        orderArray = ArrayList()
        storeArray = ArrayList()
        lateData = ArrayList()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sharedPreferencesManager.findWhichOrderCategory(Constants.DELIVERED_ORDER_BIT.toInt())
        progressVisibility(true)
        initClickListeners()
        initObservers()
        setUpRecycler()
        setListeners()
        sharedPreferencesManager.saveIsHistory(true)
    }

    private fun setListeners() {
        binding.apply {
            binding.searchBar.doAfterTextChanged { search ->
                textChangeHandler(search.toString())
            }
            rlViewOrders.addOnScrollListener(scrolling)

            binding.swipeRefreshLayoutHistory.setOnRefreshListener {
                binding.swipeRefreshLayoutHistory.isRefreshing = true
                page = 1
                orderArray.clear()
                when (sharedPreferencesManager.getWhichOrderCategory()) {
                    Constants.DELIVERED_ORDER_BIT.toInt() -> callApi(
                        Constants.DELIVERED_ORDER_BIT.toInt(), page

                    )
                    Constants.CANCEL_ORDER_BIT.toInt() -> callApi(
                        Constants.CANCEL_ORDER_BIT.toInt(), page
                    )

                }
            }
        }
    }

    private fun textChangeHandler(search: String) {
        orderArray.clear()
        when (sharedPreferencesManager.getWhichOrderCategory()) {
            Constants.CANCEL_ORDER_BIT.toInt() -> callApi(
                Constants.CANCEL_ORDER_BIT.toInt(),
                page,
                search
            )
            Constants.DELIVERED_ORDER_BIT.toInt() -> callApi(
                Constants.DELIVERED_ORDER_BIT.toInt(),
                page,
                search
            )
        }
    }


    private val scrolling = object : RecyclerView.OnScrollListener() {
        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
            super.onScrollStateChanged(recyclerView, newState)
            when (newState) {
                RecyclerView.SCROLL_STATE_IDLE -> {
                    binding.canceledOrder.isEnabled = true
                    binding.deliveredOrder.isEnabled = true
                    binding.swipeRefreshLayoutHistory.isEnabled = true
                }
                RecyclerView.SCROLL_STATE_DRAGGING -> {
                    binding.canceledOrder.isEnabled = false
                    binding.deliveredOrder.isEnabled = false
                    binding.swipeRefreshLayoutHistory.isEnabled = false
                }
            }
        }

        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            super.onScrolled(recyclerView, dx, dy)
            val layoutManager = recyclerView.layoutManager as LinearLayoutManager
            val lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition()
            val totalItemCount = layoutManager.itemCount
            if (lastVisibleItemPosition == totalItemCount - 1 && totalItemCount < (totalOrderCount
                    ?: 0) && totalItemCount > page
            ) {
                page++
                when (sharedPreferencesManager.getWhichOrderCategory()) {
                    Constants.CANCEL_ORDER_BIT.toInt() -> {
                        canceledOrderHandler(page)
                    }
                    Constants.DELIVERED_ORDER_BIT.toInt() -> {
                        deliveredOrderHandler(page)
                    }

                }
            }
        }
    }


    private fun setUpRecycler() {
        binding.rlViewOrders.layoutManager = LinearLayoutManager(requireContext())
        adapter = OrderAdapter(orderArray, this@HistoryFragment)
        binding.rlViewOrders.adapter = adapter
    }

    private fun initObservers() {
        viewModal.cafeStatus.observe(viewLifecycleOwner) {
            if (it.status.toBoolean()) {
                cafeSwitcher()
                cafeBtnChangeHandler()
            }
        }
        viewModal.showDialog.observe(viewLifecycleOwner) {
            if (it.toBoolean()) {
                sharedPreferencesManager.saveToken("")
                createDialog(requireContext(), getString(R.string.token_not_get_string))
                navigateToFragment(R.id.action_historyFragment_to_loginFragment)
            } else {
                binding.progress.visibility = View.GONE
                createDialog(requireContext(), it)
            }
        }

        viewModal.orderData.observe(viewLifecycleOwner) {
            if (it.data.isEmpty()) {
                noDataHandler(false , backgroundVisibility = true)
            } else {
                noDataHandler(true, backgroundVisibility = false)
            }
            binding.swipeRefreshLayoutHistory.isRefreshing = false
            storeArray.clear()
            totalOrderCount = it.count
            storeArray.addAll(it.data)
            orderArray.addAll(it.data)
            progressVisibility(false)
            notifyDataSetChanged()

        }

        viewModal.cancelOrder.observe(viewLifecycleOwner) {
            createDialog(requireContext(), getString(R.string.cancel_order_string))
        }
    }


    private fun noDataHandler(layoutVisibility: Boolean, backgroundVisibility: Boolean) {
        binding.swipeRefreshLayoutHistory.isVisible = layoutVisibility
        binding.noOrderFound.isVisible = backgroundVisibility
        binding.noOrderFoundText.isVisible = backgroundVisibility
        binding.noOrderFoundSubText.isVisible = backgroundVisibility
    }

    private fun cafeBtnChangeHandler() {
        if (!sharedPreferencesManager.getIsCafeOpened()) {
            binding.apply {
                closedBtnHandler()
            }
        } else {
            openButtonHandler()
        }
    }

    private fun closedBtnHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_changebackground
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_change_background
            )

            openBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.white
                )
            )

            binding.buttonLayout.visibility =View.GONE
            binding.swipeRefreshLayoutHistory.visibility = View.GONE
            binding.cafeClosedImage.visibility = View.VISIBLE
            binding.cafeClosedText.visibility = View.VISIBLE
            binding.cafeClosedSubText.visibility = View.VISIBLE
            binding.openCafeBtn.visibility = View.VISIBLE
        }
    }


    private fun openButtonHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_default_background
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_default_background
            )
            openBtn.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )

            binding.buttonLayout.visibility =View.VISIBLE
            binding.swipeRefreshLayoutHistory.visibility = View.VISIBLE
            binding.cafeClosedImage.visibility = View.GONE
            binding.cafeClosedText.visibility = View.GONE
            binding.cafeClosedSubText.visibility = View.GONE
            binding.openCafeBtn.visibility = View.GONE
        }
    }

    private fun cafeSwitcher() {
        if (sharedPreferencesManager.getIsCafeOpened()) {
            sharedPreferencesManager.saveIsCafeOpened(false)
        } else {
            sharedPreferencesManager.saveIsCafeOpened(true)
            createDialog(requireContext(), getString(R.string.open_cafe_started))
        }
    }

    private fun openCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.close_cafe_string),
            getString(R.string.close_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModal.switchCafe(Constants.CLOSE_BUTTON_BIT) {
                openButtonHandler()

            }
        }
    }

    private fun closeCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.open_cafe_string),
            getString(R.string.open_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModal.switchCafe(Constants.OPEN_BUTTON_BIT) {
                openButtonHandler()
            }
        }
    }

    private fun initClickListeners() {
        cafeBtnChangeHandler()
        binding.apply {
            canceledOrder.setOnClickListener {
                if (sharedPreferencesManager.getWhichOrderCategory() != Constants.CANCEL_ORDER_BIT.toInt()) {
                    page = 1
                    canceledOrderHandler(page)
                    sharedPreferencesManager.findWhichOrderCategory(Constants.CANCEL_ORDER_BIT.toInt())
                    orderArray.clear()
                }
            }
            deliveredOrder.setOnClickListener {
                if (sharedPreferencesManager.getWhichOrderCategory() != Constants.DELIVERED_ORDER_BIT.toInt()) {
                    page = 1
                    deliveredOrderHandler(page)
                    sharedPreferencesManager.findWhichOrderCategory(Constants.DELIVERED_ORDER_BIT.toInt())
                    orderArray.clear()
                }
            }

            openBtn.setOnClickListener {
                if (!sharedPreferencesManager.getIsCafeOpened()) {
                    closeCafe()
                }
            }
            openCafeBtn.setOnClickListener {
                if (!sharedPreferencesManager.getIsCafeOpened()) {
                    closeCafe()
                }
            }
            closeBtn.setOnClickListener {
                if (sharedPreferencesManager.getIsCafeOpened()) {
                    openCafe()
                }
            }
        }
    }


    private fun deliveredOrderHandler(page: Int) {
        progressVisibility(true)
        binding.apply {
            deliveredOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.login_button_background)
            deliveredOrder.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            canceledOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            canceledOrder.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.order_btn_color
                )
            )
        }
        callApi(Constants.DELIVERED_ORDER_BIT.toInt(), page)
    }

    private fun progressVisibility(b: Boolean) {
        binding.progress.isVisible = b
    }

    private fun canceledOrderHandler(page: Int) {
        binding.apply {
            progressVisibility(true)
            canceledOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.login_button_background)
            canceledOrder.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            deliveredOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            deliveredOrder.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.order_btn_color
                )
            )
        }
        callApi(Constants.CANCEL_ORDER_BIT.toInt(), page)
    }

    private fun callApi(i: Int, page: Int, search: String = "") {
        viewModal.getOrders(page, i, search)
    }

    override fun onResume() {
        super.onResume()
        viewModal.getOrders(1, Constants.DELIVERED_ORDER_BIT.toInt(), "")
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
        page = 1
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onItemClick(position: Int) {
        val directions =
            HistoryFragmentDirections.actionHistoryFragmentToOrderDetailFragment(orderArray[position])
        findNavController().navigate(directions)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun notifyDataSetChanged() {
        binding.rlViewOrders.adapter?.notifyDataSetChanged()
    }

    override fun cancelOrderItem(position: Int) {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.sure_message),
            getString(R.string.cancel_order_string),
            getString(R.string.cancel)
        ) {
            itemPosition = position
            viewModal.cancelOrder(
                Constants.CANCEL_ORDER_BIT,
                orderArray[position].id.toString()
            ) {

            }
        }
    }

    override fun prepareOrder(position: Int) {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.sure_message),
            getString(R.string.preparing),
            getString(R.string.cancel)
        ) {
            itemPosition = position
            viewModal.cancelOrder(
                Constants.PREPARING_ORDER_BIT,
                orderArray[position].id.toString()
            ) {
            }
        }
    }


    override fun removeOrder(position: Int) {
        binding.rlViewOrders.adapter?.notifyItemRemoved(position)
    }

    override fun deliveredOrder(position: Int) {
        Constants.FUNCTION_TO_BE_IMPLEMENTED
    }

    override fun preparedOrder(position: Int) {
        Constants.FUNCTION_TO_BE_IMPLEMENTED
    }

    override fun onSearchResult(array: DashBoardCategories, i: Int) {
        Constants.FUNCTION_TO_BE_IMPLEMENTED
    }

    override fun onSearchResultProducts(array: ProductModal, i: Int) {
        Constants.FUNCTION_TO_BE_IMPLEMENTED
    }

    override fun onSearchResultOrders(array: ArrayList<OrderModal>, i: Int) {
        orderArray.clear()
        orderArray.addAll(
            if (i == 2) getFilteredData(array)
            else if (array.isEmpty() && i == 1) storeArray else getFilteredData(array)
        )
        notifyDataSetChanged()
    }

    private fun getFilteredData(array: ArrayList<OrderModal>): ArrayList<OrderItems> {
        val resultant = ArrayList<OrderItems>()
        for ((_, i) in array) {
            for (j in i)
                resultant.add(j)
        }
        return resultant
    }

}
