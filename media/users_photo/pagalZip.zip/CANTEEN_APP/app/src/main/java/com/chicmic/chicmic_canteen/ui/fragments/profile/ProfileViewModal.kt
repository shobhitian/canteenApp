package com.chicmic.chicmic_canteen.ui.fragments.profile

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.dashboard.LogoutResponse
import com.chicmic.chicmic_canteen.modals.dashboard.UserImageResponse
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.MyApp
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream

class ProfileViewModal(application: Application) : AndroidViewModel(application) {


    companion object {
        private val sellerRepository = SellerRepository()
    }

    private val _signOut: MutableLiveData<LogoutResponse> = MutableLiveData()
    val signOut: LiveData<LogoutResponse> get() = _signOut


    private val _imageUpdate: MutableLiveData<UserImageResponse> = MutableLiveData()
    val imageUpdate: LiveData<UserImageResponse> get() = _imageUpdate

    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog

    private val _cafeStatus: MutableLiveData<LogoutResponse> = MutableLiveData()
    val cafeStatus: LiveData<LogoutResponse> get() = _cafeStatus

    fun logoutSeller(function: () -> Unit) {

        viewModelScope.launch {
            try {
                val response = sellerRepository.logOutSeller()
                if (response.isSuccessful) {
                    response.body()?.let {
                        _signOut.postValue(it)
                        function()
                    }
                } else {
                    responseCodes(responseCode = response.code())
                    function()
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }

    fun switchCafe(status: Int, function: () -> Unit) {
        viewModelScope.launch {
            try {
                val response = sellerRepository.cafeSwitch(status)
                if (response.isSuccessful) {
                    response.body()?.let {
                        _cafeStatus.postValue(it)
                        function()
                    }
                } else {
                    responseCodes(responseCode = response.code())
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }

    fun updateProfile(context: Context?, file: Uri) {
        viewModelScope.launch {
            try {
                val cacheFileName = getFileName(context!!, file)
                val cacheFile = File(context.cacheDir, cacheFileName)
                context.contentResolver.openInputStream(file)?.use { inputStream ->
                    FileOutputStream(cacheFile).use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
                val requestFile: MultipartBody.Part = MultipartBody.Part.createFormData(context.getString(
                        R.string.profile_photo
                    ), cacheFile.name, cacheFile.asRequestBody("image/*".toMediaTypeOrNull())
                )

                val mediaType = "text/plain".toMediaType()
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("profilephoto","sandwich.jpeg",
                        getFileFromUri(file).asRequestBody("application/octet-stream".toMediaType()))
                    .build()

                val response = sellerRepository.updateProfile(body = body)
                if (response.isSuccessful) {
                    response.body()?.let {
                        _imageUpdate.postValue(it)
                    }
                } else {
                    responseCodes(responseCode = response.code())
                }
            } catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }
        }
    }

    @SuppressLint("Range")
    private fun getFileName(context: Context, uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME))
                }
            }
        }
        return result ?: "cache_file"
    }




    fun getFileFromUri(uri: Uri): File {
        val contentResolver = MyApp.getContext().contentResolver
        val inputStream = contentResolver.openInputStream(uri)
        val file = File(MyApp.getContext().cacheDir, "temp_file")
        val outputStream = FileOutputStream(file)
        val buffer = ByteArray(1024)
        var length: Int
        while (inputStream?.read(buffer).also { length = it ?: 0 } != -1) {
            outputStream.write(buffer, 0, length)
        }
        outputStream.flush()
        outputStream.close()
        inputStream?.close()
        return file
    }


    private fun responseCodes(responseCode: Int) {
        when (responseCode) {

            ResponseCodes.KEY_401 -> _showDialog.postValue("true")
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_500 -> (
                    getApplication<Application>().applicationContext.getString(
                        R.string.internal_server_error
                    )
                    )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )
        }
    }

}