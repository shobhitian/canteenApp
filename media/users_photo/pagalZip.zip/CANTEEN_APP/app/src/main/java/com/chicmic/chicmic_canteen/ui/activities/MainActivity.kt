package com.chicmic.chicmic_canteen.ui.activities


import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.ActivityMainBinding
import com.chicmic.chicmic_canteen.utils.MySharedPreferencesManager
import com.chicmic.chicmic_canteen.utils.showConfirmationDialog
import com.chicmic.chicmic_canteen.utils.showToast

import timber.log.Timber

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sharedPreferencesManager: MySharedPreferencesManager
    private lateinit var navController : NavController


    companion object {
        private const val TAG = "MAIN ACTIVITY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initialize()
    }

    private fun initialize() {
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(this)
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment
       navController = navHostFragment.navController
        val navView: com.google.android.material.bottomnavigation.BottomNavigationView =
            findViewById(R.id.bottomNavigation)
        // Hook your navigation controller to bottom navigation view
        navView.setupWithNavController(navController)
        setUpBottomNavigation()

    }

    private fun setUpBottomNavigation() {
        val onBackPressedCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                showConfirmationDialog(this@MainActivity , getString(R.string.close_app_message) , getString(
                                    R.string.ok) , getString(R.string.cancel) ){finish()}
            }
        }
        onBackPressedDispatcher.addCallback( this@MainActivity, onBackPressedCallback)
    }

    override fun onResume() {
        super.onResume()
        navigationToWhichFragment()
    }

    private fun navigationToWhichFragment() {
        val token = sharedPreferencesManager.getToken()
        try {
            if (token?.isEmpty() != true) {
                findNavController(R.id.fragmentContainerView).navigate(R.id.action_loginFragment_to_dashboardFragment)
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e)
        }

    }


    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { isGranted: Boolean ->
        if (isGranted) {
            showToast(this, getString(R.string.permission_granted))
        } else {
          askNotificationPermission()
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                // FCM SDK (and your app) can post notifications.
            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                showConfirmationDialog(this ,
                    getString(R.string.permission_message),
                    getString(R.string.grant_permission),
                    getString(R.string.cancel)
                ) { requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            } else {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }


    fun setBottomVisibility(isVisible: Boolean) {
        binding.bottomNavigation.isVisible = isVisible
    }


}
