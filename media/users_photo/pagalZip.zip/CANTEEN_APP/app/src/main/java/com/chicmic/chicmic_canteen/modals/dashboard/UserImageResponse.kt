package com.chicmic.chicmic_canteen.modals.dashboard

import com.google.gson.annotations.SerializedName

data class UserImageResponse(
    val data : UserData,
    val message: String,
    val response: String,
    val status: Boolean
)

data class UserData(
    val email: String,
    @SerializedName("first_name")
    val firstName: String,
    val id: Int,
    @SerializedName("last_name")
    val lastName: String,
    val profileDetails: ProfileDetails,
    val username: String
)

data class ProfileDetails(
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("device_type")
    val deviceType: Int,
    @SerializedName("emp_code")
    val empCode: Any,
    @SerializedName("fcm_token")
    val fcmToken: Any,
    val gender: Any,
    val id: Int,
    val otp: Any,
    @SerializedName("phone_number")
    val phoneNumber: Any,
    val photo: String,
    @SerializedName("ref_user")
    val refUser: Int,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("user_type")
    val userType: Int,
    val uuid: String,
    val verified: Boolean,
    @SerializedName("web_token")
    val webToken: Any,
    @SerializedName("year_of_joining")
    val yearOfJoining: Int
)