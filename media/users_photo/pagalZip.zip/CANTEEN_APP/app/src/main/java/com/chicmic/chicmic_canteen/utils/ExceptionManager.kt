package com.chicmic.chicmic_canteen.utils

import timber.log.Timber
import kotlin.reflect.KSuspendFunction1

class ExceptionManager() {

    suspend fun  exceptionHandler(task: KSuspendFunction1<Any, Unit>, tag: String , data : Any) {
        try {
            task(data)
        } catch (e: Exception) {
            Timber.tag(tag).e("$e")
        }
    }

}