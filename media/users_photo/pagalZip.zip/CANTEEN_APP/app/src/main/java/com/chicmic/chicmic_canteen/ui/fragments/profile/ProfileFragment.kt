package com.chicmic.chicmic_canteen.ui.fragments.profile


import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.CustomSignOutDialogBinding
import com.chicmic.chicmic_canteen.databinding.FragmentProfileBinding
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.chicmic.chicmic_canteen.ui.fragments.reset.ResetPasswordFragment
import com.chicmic.chicmic_canteen.utils.*
import timber.log.Timber
import java.io.File

class ProfileFragment : Fragment() {


    private lateinit var imageUri: Uri
    private var cameraFlag: Boolean? = null

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var permissionHelper: PermissionHelper
    private lateinit var viewModal: ProfileViewModal
    private lateinit var sharedPreference: MySharedPreferencesManager
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        initializeVariables()

        return binding.root
    }

    private fun initializeVariables() {
        permissionHelper = PermissionHelper(requireContext())
        viewModal = ViewModelProvider(this)[ProfileViewModal::class.java]
        sharedPreference = MySharedPreferencesManager.getInstance(requireContext())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            (activity as MainActivity).supportActionBar?.hide()
            (activity as MainActivity).setBottomVisibility(true)
        }
        initializeClickListeners()
        initializeObserver()
        setUpScreen()
    }

    private fun setUpScreen() {
        cafeBtnChangeHandler()
        binding.apply {
            userName.text = sharedPreference.getUserName()
            userMail.text = sharedPreference.getUserEmail()

            Glide.with(requireContext())
                .load("${Constants.BASE_URL}${sharedPreference.getUserImage()}")
                .into(userImage)
        }
    }

    private fun initializeClickListeners() {
        binding.singOutBtn.setOnClickListener {
            binding.singOutBtn.isEnabled = false
            createLogoutDialog()
        }
        binding.resetPasswordButton.setOnClickListener {
            binding.resetPasswordButton.isEnabled = false
            createResetDialogFragment()
        }
        binding.openBtn.setOnClickListener {
            if (!sharedPreference.getIsCafeOpened()) {
                closeCafe()
            }
        }
        binding.closeBtn.setOnClickListener {
            if (sharedPreference.getIsCafeOpened()) {
                openCafe()
            }
        }
        binding.ivImageUpload.setOnClickListener {
            openChooserDialog()
        }
    }

    /**
     *  camera contract -> opens the camera for the capturing image.
     */
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { imageClicked ->
            if (imageClicked) {
                setImage(imageUri)
            } else
                Timber.tag("image is not clicked or deny by the user")
        }

    /**
     *  image contract -> opens the gallery for selecting the image.
     */
    private val imageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { image ->
            if (image != null) {
                setImage(image)
            } else
                Timber.tag("image is not selected by the user")
        }

    /**
     * permission contract -> give the prompt to the user to asked the necessary permission needed.
     */
    private val askPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (checkPermissionArray(it)) {
                if (cameraFlag == true)
                    cameraLauncher.launch(imageUri)
                else
                    imageLauncher.launch(Constants.IMAGE_KEY)
            }
        }

    /** function calls when the user click on the  (ivImageUpload) view .
     *  prompts the user with the dialog to select the camera or gallery option .
     */
    private fun openChooserDialog() {
        showImageOptionDialog(requireContext(),
            getString(R.string.select),
            getString(R.string.camera),
            getString(R.string.gallery),
            cameraBtnClicked = { cameraOptionSelected() },
            galleryBtnClicked = { galleryOptionSelected() })
    }


    /**
     *  function calls when user select the gallery option.
     *  result array-> gives the array for the denial permission if it is empty -> needed contract will be launched
     *  and if user has denies previously it will prompt the user to the setting App for the allowance of the necessary permission.
     */
    private fun galleryOptionSelected() {
        val resultArray = permissionHelper.checkHasPermission(false)
        if (resultArray.isEmpty()) {
            imageLauncher.launch(Constants.IMAGE_KEY)
            return
        }

        if (checkRationaleState(resultArray)) {
            // navigate to the settings screen
            navigateToSettingsScreen()
            return
        }
        cameraFlag = false
        askPermission.launch(resultArray)
    }

    /**
     * function which navigates the user to the settings App if the user has denied the permission more than once.
     */
    private fun navigateToSettingsScreen() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts(Constants.PACKAGE, requireContext().packageName, null)
        requireContext().startActivity(intent)
    }


    /**
     *  check state function checks if the user has denied the permission more than once than it must be prompted to the setting screen .
     *  it will check if any of the permission is denied more than once it navigates to the settings screen.
     */
    private fun checkRationaleState(pArray: Array<String>): Boolean {
        for (i in pArray) {
            if (shouldShowRequestPermissionRationale(i)) {
                return true
            }
        }
        return false
    }

    /**
     *  function calls when user select the camera option.
     *  result array-> gives the array for the denial permission if it is empty -> needed contract will be launched
     *  and if user has denies previously it will prompt the user to the setting App for the allowance of the necessary permission.
     */
    private fun cameraOptionSelected() {
        val resultArray = permissionHelper.checkHasPermission(true)
        val file = File(requireContext().externalCacheDir, "temp.jpg")
        imageUri = FileProvider.getUriForFile(
            requireContext(),
            Constants.FILE_PROVIDER,
            file
        )

        if (resultArray.isEmpty()) {
            cameraLauncher.launch(imageUri)
            return
        }

        if (checkRationaleState(resultArray)) {
            // navigate to the settings screen
            navigateToSettingsScreen()
            return
        }
        cameraFlag = true
        askPermission.launch(resultArray)

    }


    private fun initializeObserver() {
        viewModal.signOut.observe(viewLifecycleOwner) {
            sharedPreference.saveToken("")
            navigateToFragment(R.id.action_profileFragment_to_loginFragment)
        }

        viewModal.cafeStatus.observe(viewLifecycleOwner) {
            if (it.status.toBoolean()) {
                cafeSwitcher()
                cafeBtnChangeHandler()
            }
        }

        viewModal.imageUpdate.observe(viewLifecycleOwner) {
            createDialog(requireContext(), "Image has been uploaded Successfully")
            sharedPreference.saveUserImage("${Constants.BASE_URL}${it.data.profileDetails.photo}")
            Glide.with(requireContext()).load(sharedPreference.getUserImage()?.toUri()).into(binding.userImage)
        }
        viewModal.showDialog.observe(viewLifecycleOwner) {
            if (it.toBoolean()) {
                sharedPreference.saveToken("")
                createDialog(requireContext(), getString(R.string.token_not_get_string))
                navigateToFragment(R.id.action_profileFragment_to_loginFragment)
            } else {
                binding.progress.visibility = View.GONE
                createDialog(requireContext(), it)
            }

        }
    }

    private fun cafeBtnChangeHandler() {
        if (!sharedPreference.getIsCafeOpened()) {
            binding.apply {
                closedBtnHandler()
            }
        } else {
            openButtonHandler()
        }
    }

    private fun createLogoutDialog() {
        val builder = Dialog(requireContext())
        val bindingDialog = CustomSignOutDialogBinding.inflate(layoutInflater)
        builder.setContentView(bindingDialog.root)
        bindingDialog.cancelButtonSignOut.setOnClickListener {
            bindingDialog.progressBarSignOut.visibility = View.GONE
            binding.singOutBtn.isEnabled = true
            builder.cancel()
        }
        bindingDialog.logoutDialogSignOut.setOnClickListener {
            bindingDialog.logoutDialogSignOut.isEnabled = false
            bindingDialog.progressBarSignOut.visibility = View.VISIBLE
            signOut(builder)
        }
        builder.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog_background)
        builder.show()
    }

    private fun createResetDialogFragment() {
        val resetDialog = ResetPasswordFragment { changePasswordBtn(true) }
        resetDialog.show(parentFragmentManager, getString(R.string.my_dialog))
        resetDialog.showsDialog = true
    }


    private fun changePasswordBtn(visitOption: Boolean) {
        binding.resetPasswordButton.isEnabled = visitOption
    }


    private fun closedBtnHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_changebackground
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_change_background
            )

            openBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.white
                )
            )
        }
    }


    private fun openButtonHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_default_background
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_default_background
            )
            openBtn.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )
        }
    }

    private fun cafeSwitcher() {
        if (sharedPreference.getIsCafeOpened()) {
            sharedPreference.saveIsCafeOpened(false)
        } else {
            sharedPreference.saveIsCafeOpened(true)
            createDialog(requireContext(), "Let's get started !! cafe is open now")
        }
    }

    private fun openCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.close_cafe_string),
            getString(R.string.close_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModal.switchCafe(Constants.CLOSE_BUTTON_BIT) {
                openButtonHandler()
            }
        }
    }

    private fun closeCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.open_cafe_string),
            getString(R.string.open_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModal.switchCafe(Constants.OPEN_BUTTON_BIT) {
                openButtonHandler()
            }
        }
    }


    private fun signOut(dialog: Dialog) {
        viewModal.logoutSeller() {
            dialog.cancel()
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    /**
     * function which generally handles the response given by the permission contract.
     */
    private fun checkPermissionArray(pMap: Map<String, Boolean>): Boolean {
        for (i in pMap) {
            if (i.value)
                continue
            return false
        }
        return true
    }

    /**
     *  function invokes when the image contract callbacks are successfully returned
     *  shared pref store the uri of the image because image only retrieved from the api on the login time
     *  and to maintain the image track we save it in shared pref.
     */
    private fun setImage(uri: Uri) {
        Glide.with(requireContext()).load(uri).into(binding.userImage)
        sharedPreference.saveUserSelectedImage(uri.toString())
        viewModal.updateProfile(context, uri)
    }
}