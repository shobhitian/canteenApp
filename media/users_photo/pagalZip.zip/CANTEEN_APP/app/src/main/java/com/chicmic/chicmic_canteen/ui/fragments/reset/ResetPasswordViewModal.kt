package com.chicmic.chicmic_canteen.ui.fragments.reset

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.dashboard.LogoutResponse
import com.chicmic.chicmic_canteen.modals.dashboard.ResetPasswordModal
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.launch

class ResetPasswordViewModal(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "RESET_PASSWORD_VIEW_MODAL"
        private val sellerRepository = SellerRepository()
    }

    private val _resetPassword: MutableLiveData<LogoutResponse> = MutableLiveData()
    val resetPassword: LiveData<LogoutResponse> get() = _resetPassword

    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog

     fun changePassword( data: ResetPasswordModal) {

             viewModelScope.launch {
                 try {
                     val response = sellerRepository.resetPassword( data)
                     if (response.isSuccessful) {
                         response.body()?.let {
                             _resetPassword.postValue(it)
                         }
                     } else
                         responseCodes(response.code())
                 } catch (e: java.lang.Exception) {
                     _showDialog.postValue(getException(e))
                 }
             }
    }


    private fun responseCodes(responseCode: Int) {
        when (responseCode) {
            ResponseCodes.KEY_400 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.old_password_not_match
                )
            )
            ResponseCodes.KEY_401 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.invalid_cred
                )
            )
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_500  -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )
        }
    }


}