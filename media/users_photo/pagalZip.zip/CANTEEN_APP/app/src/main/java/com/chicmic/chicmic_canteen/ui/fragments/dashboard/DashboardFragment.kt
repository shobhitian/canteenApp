package com.chicmic.chicmic_canteen.ui.fragments.dashboard

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.FragmentDashboardBinding
import com.chicmic.chicmic_canteen.modals.dashboard.DashBoardCategories
import com.chicmic.chicmic_canteen.modals.dashboard.ProductModal
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.chicmic.chicmic_canteen.ui.recyclers.CategoryAdapters
import com.chicmic.chicmic_canteen.ui.recyclers.ProductsAdapter
import com.chicmic.chicmic_canteen.utils.*


class DashboardFragment : Fragment(), CategoryAdapters.OnItemClickListener,
    ProductsAdapter.OnItemClickListener {


    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private lateinit var recyclerAdapter: CategoryAdapters
    private lateinit var productsArray: ProductModal
    private lateinit var storeDataProducts: ProductModal
    private lateinit var categoryData: DashBoardCategories
    private lateinit var storeData: DashBoardCategories
    private lateinit var productAdapter: ProductsAdapter
    private lateinit var viewModel: DashBoardViewModal
    private var page: Int = 1
    private var totalOrderCount: Int? = 0
    private var productPosition: Int? = 0
    private lateinit var sharedPreferencesManager: MySharedPreferencesManager
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        screenSetup()
        return binding.root
    }

    private fun screenSetup() {
        if (activity != null) {
            (activity as MainActivity).apply {
                supportActionBar?.hide()
                setBottomVisibility(true)
                changeTopBarColor(requireContext(), window, R.color.white)
            }
        }
    }

    private fun setObservers() {
        viewModel.categoryData.observe(viewLifecycleOwner) {
            if (it.data.isEmpty()) {
                noDataHandler(layoutVisibility = false, backgroundVisibility = true)
            } else {
                noDataHandler(layoutVisibility = true, backgroundVisibility = false)
            }

            binding.progress.visibility = View.GONE
            categoryData.data.addAll(it.data)
            storeData.data.addAll(it.data)
            notifyDataSetChanged {
                callApiCategory(sharedPreferencesManager.getWhichOrderCategory())
            }
        }



        viewModel.cafeStatus.observe(viewLifecycleOwner) {
            if (it.status.toBoolean()) {
                cafeSwitcher()
                cafeBtnChangeHandler()
            }
        }
        viewModel.showDialog.observe(viewLifecycleOwner) {
            if (it.toBoolean()) {
                sharedPreferencesManager.saveToken("")
                createDialog(requireContext(), getString(R.string.token_not_get_string))
                navigateToFragment(R.id.action_dashboardFragment_to_loginFragment)
            } else {
                binding.progress.visibility = View.GONE
                createDialog(requireContext(), it)
            }
        }


        viewModel.toggleProduct.observe(viewLifecycleOwner) {
            binding.progress.visibility = View.GONE
            createDialog(requireContext(), getString(R.string.product_stock_changed))
            binding.recyclerViewProducts.adapter?.notifyItemChanged(productPosition!!)
        }

        viewModel.productsData.observe(viewLifecycleOwner) {
            if (it.result.data.isEmpty()) {
                noDataHandler(layoutVisibility = false, backgroundVisibility = true)
            } else {
                noDataHandler(layoutVisibility = true, backgroundVisibility = false)
            }

            binding.swipeRefreshLayout.isRefreshing = false
            binding.progress.visibility = View.GONE
            totalOrderCount = it.count
            productsArray.result.data.addAll(it.result.data)
            notifyDataSetChangedProduct()

        }
    }


    private fun noDataHandler(layoutVisibility: Boolean, backgroundVisibility: Boolean) {
        binding.swipeRefreshLayout.isVisible = layoutVisibility
        binding.noOrderFound.isVisible = backgroundVisibility
        binding.noOrderFoundText.isVisible = backgroundVisibility
        binding.noOrderFoundSubText.isVisible = backgroundVisibility
    }

    private fun openCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.close_cafe_string),
            getString(R.string.close_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModel.switchCafe(Constants.CLOSE_BUTTON_BIT) {
                closedBtnHandler()
            }
        }
    }

    private fun closeCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.open_cafe_string),
            getString(R.string.open_cafe_btn),
            getString(R.string.cancel)
        ) {

            viewModel.switchCafe(Constants.OPEN_BUTTON_BIT) {
                openButtonHandler()
            }
        }
    }

    private fun initialize() {
        viewModel = ViewModelProvider(this)[DashBoardViewModal::class.java]
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(requireContext())
        setUpArrays()
        setUpProductsAdapter()
        setUpCategoryAdapter()
    }

    private fun setUpArrays() {
        categoryData = DashBoardCategories()
        storeData = DashBoardCategories()
        productsArray = ProductModal()
        storeDataProducts = ProductModal()
    }

    private fun setUpProductsAdapter() {
        productAdapter = ProductsAdapter(productsArray, this@DashboardFragment)
        binding.recyclerViewProducts.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewProducts.adapter = productAdapter
    }

    private fun setUpCategoryAdapter() {
        binding.categoryRecyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        recyclerAdapter = CategoryAdapters(categoryData, this@DashboardFragment)
        binding.categoryRecyclerView.adapter = recyclerAdapter

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialize()
        initClickListeners()
        setObservers()
        setListeners()
        sharedPreferencesManager.findWhichOrderCategory(Constants.NEW_ORDER_BIT.toInt())
    }

    private fun setListeners() {
        binding.apply {

            searchBar.doAfterTextChanged {
                productsArray.result.data.clear()
                callApiProduct(
                    sharedPreferencesManager.getWhichOrderCategory(),
                    page,
                    it.toString()
                )
            }
            openBtn.setOnClickListener {
                if (!sharedPreferencesManager.getIsCafeOpened()) {
                    closeCafe()
                }
            }
            openCafeBtn.setOnClickListener {
                if (!sharedPreferencesManager.getIsCafeOpened()) {
                    closeCafe()
                }
            }
            closeBtn.setOnClickListener {
                if (sharedPreferencesManager.getIsCafeOpened()) {
                    openCafe()
                }
            }
            recyclerViewProducts.addOnScrollListener(scrolling)
            swipeRefreshLayout.setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                page = 1
                    productsArray.result.data.clear()
                    callApiProduct(sharedPreferencesManager.getWhichOrderCategory(), page)
            }
        }
    }

    private val scrolling = object : RecyclerView.OnScrollListener() {
        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
            super.onScrollStateChanged(recyclerView, newState)
            when (newState) {
                RecyclerView.SCROLL_STATE_IDLE -> {
                    binding.swipeRefreshLayout.isEnabled = true
                }
                RecyclerView.SCROLL_STATE_DRAGGING -> {
                    binding.swipeRefreshLayout.isEnabled = false
                }
                RecyclerView.SCROLL_STATE_SETTLING -> {
                    binding.swipeRefreshLayout.isEnabled = false
                }

            }
        }

        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            super.onScrolled(recyclerView, dx, dy)
            val layoutManager = recyclerView.layoutManager as LinearLayoutManager
            val lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition()
            val totalItemCount = layoutManager.itemCount
            if (lastVisibleItemPosition == totalItemCount - 1 && totalItemCount < (totalOrderCount
                    ?: 0) && totalItemCount > page
            ) {
                callApiProduct(sharedPreferencesManager.getWhichOrderCategory(), page)
                page++
            }
        }
    }

    private fun openButtonHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_default_background
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_default_background
            )
            openBtn.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )


            binding.categoryRecyclerView.visibility =View.VISIBLE
            binding.swipeRefreshLayout.visibility = View.VISIBLE
            binding.cafeClosedImage.visibility = View.GONE
            binding.cafeClosedText.visibility = View.GONE
            binding.cafeClosedSubText.visibility = View.GONE
            binding.openCafeBtn.visibility = View.GONE
        }
    }

    private fun closedBtnHandler() {
        binding.apply {

            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_changebackground
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_change_background
            )

            openBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.white
                )
            )

            binding.categoryRecyclerView.visibility =View.GONE
            binding.swipeRefreshLayout.visibility = View.GONE
            binding.cafeClosedImage.visibility = View.VISIBLE
            binding.cafeClosedText.visibility = View.VISIBLE
            binding.cafeClosedSubText.visibility = View.VISIBLE
            binding.openCafeBtn.visibility = View.VISIBLE


        }
    }

    override fun onResume() {
        super.onResume()
        binding.progress.visibility = View.VISIBLE
        binding.noDataFoundText.visibility = View.GONE
        binding.noDataFoundImage.visibility = View.GONE
        callApi()
        recyclerAdapter.flag = true
    }


    private fun initClickListeners() {
        cafeBtnChangeHandler()
    }

    private fun cafeBtnChangeHandler() {
        if (!sharedPreferencesManager.getIsCafeOpened()) {
            binding.apply {
                closedBtnHandler()
            }
        } else {
            openButtonHandler()
        }
    }

    private fun cafeSwitcher() {
        if (sharedPreferencesManager.getIsCafeOpened()) {
            sharedPreferencesManager.saveIsCafeOpened(false)
        } else {
            sharedPreferencesManager.saveIsCafeOpened(true)
            createDialog(requireContext(), getString(R.string.open_cafe_started))
        }
    }


    private fun callApi() {
        categoryData.data.clear()
        viewModel.getAllCategories()
        viewModel.getAllProductsForACategory(1)

    }

    private fun callApiCategory(id: Int) {
        binding.progress.visibility = View.VISIBLE
        viewModel.getAllProductsForACategory(id)
    }


    private fun callApiProduct(id: Int, page: Int, search: String = Constants.KEY_STRING_DEFAULT) {
        binding.progress.visibility = View.VISIBLE
        viewModel.getAllProductsForACategory(id, page, search)

    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    override fun onItemClick(position: Int, oldPosition: Int) {
        page = 1
        sharedPreferencesManager.findWhichOrderCategory(categoryData.data[position].id)
        categoryData.data.forEach { it.selection = false }
        categoryData.data[position].selection = true
        productsArray.result.data.clear()
        callApiCategory(categoryData.data[position].id)
        notifyDataSetChanged {}
    }


    @SuppressLint("NotifyDataSetChanged")
    override fun notifyDataSetChanged(kFunction0: () -> Unit) {
        binding.categoryRecyclerView.adapter?.notifyDataSetChanged()
    }

    override fun onItemClickProduct(position: Int, call: () -> Unit) {
        binding.progress.visibility = View.VISIBLE
        productPosition = position
        viewModel.toggleProduct(productsArray.result.data[position].id)
        call()
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun notifyDataSetChangedProduct() {
        (binding.recyclerViewProducts.adapter as ProductsAdapter).notifyDataSetChanged()
    }


}