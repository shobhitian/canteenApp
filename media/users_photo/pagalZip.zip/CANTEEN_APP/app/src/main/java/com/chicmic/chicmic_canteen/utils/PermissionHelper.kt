package com.chicmic.chicmic_canteen.utils

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat


/**
 *  permission helper for the handling of the necessary permissions.
 */
class PermissionHelper(val context: Context) {


    private val androidVersion = Build.VERSION.SDK_INT

    private val cameraPermission=android.Manifest.permission.CAMERA
    private val readExternalStoragePermission=android.Manifest.permission.READ_EXTERNAL_STORAGE
    private val readMediaImagesPermission=android.Manifest.permission.READ_MEDIA_IMAGES


    /**
     *  function check the permissions which are granted from the pArray and it returns the array for the permission which is not granted.
     */
    private fun checkHasPermission(pArray: Array<String>):Array<String>{
        var pDenialArray :Array<String> = arrayOf()
        for(i in pArray){
            if(ContextCompat.checkSelfPermission(context,i)==PackageManager.PERMISSION_GRANTED)
                continue
            pDenialArray += i
        }
        return pDenialArray
    }

    /**
     *  function which checks the permission for the two cases->
     *
     *  1.) if the user have selected the gallery option from the profile fragment. isCamera(false)
     *  2.) if the user have selected the camera option from the profile fragment.  isCamera(true)
     *
     *  isCamera helps in understanding which permission needs to be checked for which case.
     *  above method and this method has relationship of method overloading.
     */
    fun checkHasPermission(isCamera:Boolean):Array<String>{
        if(isCamera){
            return checkHasPermission(arrayOf(cameraPermission))
        }

        if(androidVersion<Build.VERSION_CODES.TIRAMISU){
            return checkHasPermission(arrayOf(readExternalStoragePermission))
        }

        return checkHasPermission(arrayOf(readMediaImagesPermission))
    }
}