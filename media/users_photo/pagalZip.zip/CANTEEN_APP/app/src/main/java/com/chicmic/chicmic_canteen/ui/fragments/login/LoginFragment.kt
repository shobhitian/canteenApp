package com.chicmic.chicmic_canteen.ui.fragments.login

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.LoginDemoBinding
import com.chicmic.chicmic_canteen.firebase.FireBasePushNotifications
import com.chicmic.chicmic_canteen.modals.Login
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.chicmic.chicmic_canteen.utils.*
import com.google.android.material.textfield.TextInputLayout


class LoginFragment : Fragment(), ValidateResultInterface {

    private var _binding: LoginDemoBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: LoginViewModel
    private lateinit var sharedPreference: MySharedPreferencesManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = LoginDemoBinding.inflate(inflater, container, false)
        initialize()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        activity?.let {
            removeActionBar(it, requireContext())
            changeTopBarColor(
                requireContext(),
                (activity as MainActivity).window,
                R.color.status_bar_color
            )
        }
    }

    private fun initialize() {
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        sharedPreference = MySharedPreferencesManager.getInstance(requireContext())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initClickListener()
        initObserver()
        setListeners()
    }

    private fun setListeners() {
        binding.etLoginEmail.addTextChangedListener(
            ValidationTextWatcher(
                Constants.EMAIL_VALIDATION,
                this@LoginFragment,
                 binding.loginEmail,
                ValidatorTypes.EMAIL
            )
        )
    }


    private fun initObserver() {
        viewModel.loginResponse.observe(viewLifecycleOwner) {
            afterApiHit(true)
            if(it.data != null)
            {
                sharedPreference.saveToken("Bearer ${it.token}")
                "${it.data.first_name} ${it.data.last_name}".also { name -> sharedPreference.saveUserName(name) }
                sharedPreference.saveUserEmail(it.data.email)
                sharedPreference.saveUserImage(it.data.photo)
            }
            navigateToDashboard()
        }
        viewModel.showDialog.observe(viewLifecycleOwner) {
            afterApiHit(true)
            createDialog(requireContext(), it?:"")
        }
    }

    private fun afterApiHit(visibility: Boolean) {
        binding.apply {
            if (visibility) {
                submitButton.isEnabled = true
                progress.visibility = View.GONE
            } else {
                submitButton.isEnabled = false
                progress.visibility = View.VISIBLE
            }

        }
    }


    private fun navigateToDashboard() {
        findNavController().navigate(R.id.action_loginFragment_to_dashboardFragment)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initClickListener() {
        binding.apply {
            submitButton.setOnClickListener {
                submitButtonListener()
            }
            forgotPassword.setOnClickListener {
                findNavController().navigate(R.id.action_loginFragment_to_forgotPassword2)
            }
        }
    }


    private fun validatedData(): Boolean {
        binding.apply {
            return when {
                binding.etLoginEmail.text?.let {
                    Patterns.EMAIL_ADDRESS.matcher(it).matches()
                } != true -> false
                binding.etLoginPassword.text?.trim()?.length!! < 4 -> false
                sharedPreference.getUserDeviceToken().toString().isEmpty() -> {
                    FireBasePushNotifications().getTokenAgain()
                    true
                }
                else -> true
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    override fun onValidationResult(isValid: Boolean, loginEmail: TextInputLayout) {
      if(isValid){
          loginEmail.setBackgroundResource(R.drawable.login_fields_background)
       }
        else
      {
          loginEmail.setBackgroundResource(R.drawable.login_background_error)
      }
    }



    private fun submitButtonListener() {
        afterApiHit(false)
        if (validatedData()) {
            viewModel.loginSeller(
                Login(
                    binding.etLoginEmail.text.toString(),
                    binding.etLoginPassword.text.toString(),
                    sharedPreference.getUserDeviceToken().toString(),
                    Constants.DEVICE_TYPE
                )
            )
        } else {
            createDialog(requireContext(), getString(R.string.emailAndPassword))
            afterApiHit(true)
        }
    }
}



