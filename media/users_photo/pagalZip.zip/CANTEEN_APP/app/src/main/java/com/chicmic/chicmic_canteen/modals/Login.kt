package com.chicmic.chicmic_canteen.modals

data class Login(
    val email: String,
    val password: String,
    val fcm_token : String ,
    val device_type :Int =1
)

data class LoginResponse(
    val message : String?,
    val status : Boolean?,
    val response : String?,
    val token : String?,
    val data : UserData?,

)

data class UserData(
    val user_type : Int,
    val username : String,
    val user_id : Int,
    val photo : String,
    val email : String,
    val first_name : String,
    val last_name : String,
)
