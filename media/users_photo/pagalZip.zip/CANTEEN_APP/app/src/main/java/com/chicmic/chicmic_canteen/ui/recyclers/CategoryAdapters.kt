package com.chicmic.chicmic_canteen.ui.recyclers


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.ItemCategoriesBinding
import com.chicmic.chicmic_canteen.modals.dashboard.DashBoardCategories
import com.chicmic.chicmic_canteen.utils.capitalizeSentences

class CategoryAdapters(
    private val categoryData: DashBoardCategories,
    private val listener: OnItemClickListener
) :
    RecyclerView.Adapter<CategoryAdapters.ViewHolder>() {

    var flag = true
    inner class ViewHolder(val binding: ItemCategoriesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.categoryBtn.setOnClickListener {
                listener.onItemClick(adapterPosition, oldPosition )
            }
        }

    }

    interface OnItemClickListener {
        fun onItemClick(position: Int, oldPosition: Int  )
        fun notifyDataSetChanged( kFunction0: () -> Unit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemCategoriesBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }


    override fun getItemCount(): Int {
        return categoryData.data.size
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            categoryBtn.text = (categoryData.data[position].name).capitalizeSentences()
            if (categoryData.data[position].selection || flag ) {
                flag = false
                categoryBtn.background = ContextCompat.getDrawable(root.context, R.drawable.login_button_background)
                categoryBtn.setTextColor(root.context.getColor(R.color.white))
            } else {
                categoryBtn.background =
                    ContextCompat.getDrawable(root.context, R.drawable.order_btn_background)
                categoryBtn.setTextColor(root.context.getColor(R.color.order_btn_color))
            }
        }
    }
}