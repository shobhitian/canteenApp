package com.chicmic.chicmic_canteen.ui.fragments.order

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.databinding.FragmentOrderBinding
import com.chicmic.chicmic_canteen.modals.dashboard.*
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.chicmic.chicmic_canteen.ui.recyclers.OrderAdapter
import com.chicmic.chicmic_canteen.utils.*
import timber.log.Timber


class OrderFragment : Fragment(), OrderAdapter.OnItemClickListener {

    companion object {
        private const val TAG = "ORDER_FRAGMENT"
    }

    private var _binding: FragmentOrderBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModal: OrderViewModal
    private lateinit var sharedPreferencesManager: MySharedPreferencesManager
    private lateinit var adapter: OrderAdapter
    private var itemPosition: Int? = 0
    private var totalOrderCount: Int? = 0
    private var page = 1
    private lateinit var orderArray: ArrayList<OrderItems>
    private lateinit var storeArray: ArrayList<OrderItems>
    private var token: String? = null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOrderBinding.inflate(inflater, container, false)
        initializeVariables()
        screenSetup()
        return binding.root
    }

    private fun screenSetup() {
        if (activity != null) {
            (activity as MainActivity).apply {
                supportActionBar?.hide()
                setBottomVisibility(true)
                changeTopBarColor(requireContext(), window, R.color.white)
            }
        }
    }

    private fun initializeVariables() {
        viewModal = ViewModelProvider(this)[OrderViewModal::class.java]
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(requireContext())
        orderArray = ArrayList()
        storeArray = ArrayList()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        progressVisibility(true)
        initClickListeners()
        initObservers()
        setUpRecycler()
        setListeners()
        sharedPreferencesManager.findWhichOrderCategory(Constants.NEW_ORDER_BIT.toInt())
        sharedPreferencesManager.saveIsHistory(false)
    }

    private fun setListeners() {
        with(binding) {
            rlViewOrders.addOnScrollListener(scrolling)
        }
        binding.searchBar.addTextChangedListener(textChanged)
        binding.swipeRefreshLayout.setOnRefreshListener {
            binding.swipeRefreshLayout.isRefreshing = true
            page = 1
            if (token != null) {
                orderArray.clear()
                when (sharedPreferencesManager.getWhichOrderCategory()) {
                    Constants.NEW_ORDER_BIT.toInt() -> callApi(Constants.NEW_ORDER_BIT.toInt(), page)
                    Constants.PREPARING_ORDER_BIT.toInt() -> callApi(Constants.PREPARING_ORDER_BIT.toInt(), page)
                    Constants.PREPARED_ORDER_BIT.toInt() -> callApi(Constants.PREPARED_ORDER_BIT.toInt(), page)
                }
            }
        }
    }

    private val textChanged = object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            Timber.tag(TAG).e("$p0")
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            Timber.tag(TAG).e("$p0")
        }

        override fun afterTextChanged(p0: Editable?) {
            orderArray.clear()
            when (sharedPreferencesManager.getWhichOrderCategory()) {
                Constants.NEW_ORDER_BIT.toInt() -> callApi(
                    Constants.NEW_ORDER_BIT.toInt(),
                    page,
                    p0.toString()
                )
                Constants.PREPARING_ORDER_BIT.toInt() -> callApi(
                    Constants.PREPARING_ORDER_BIT.toInt(),
                    page,
                    p0.toString()
                )
                Constants.PREPARED_ORDER_BIT.toInt() -> callApi(
                    Constants.PREPARED_ORDER_BIT.toInt(),
                    page,
                    p0.toString()
                )
            }
        }
    }


    private val scrolling = object : RecyclerView.OnScrollListener() {
        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
            super.onScrollStateChanged(recyclerView, newState)
            when (newState) {
                RecyclerView.SCROLL_STATE_IDLE -> {
                    binding.prepared.isEnabled = true
                    binding.preparing.isEnabled = true
                    binding.newOrder.isEnabled = true
                }
                RecyclerView.SCROLL_STATE_DRAGGING -> {
                    binding.prepared.isEnabled = false
                    binding.preparing.isEnabled = false
                    binding.newOrder.isEnabled = false
                }
            }
        }

        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            super.onScrolled(recyclerView, dx, dy)
            val layoutManager = recyclerView.layoutManager as LinearLayoutManager
            val lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition()
            val totalItemCount = layoutManager.itemCount
            if (lastVisibleItemPosition == totalItemCount - 1 && totalItemCount < (totalOrderCount
                    ?: 0) && totalItemCount > page
            ) {
                page++
                when (sharedPreferencesManager.getWhichOrderCategory()) {
                    Constants.NEW_ORDER_BIT.toInt() -> {
                        newOrderHandler(page)
                    }
                    Constants.PREPARING_ORDER_BIT.toInt() -> {
                        preparingOrderHandler(page)
                    }
                    Constants.PREPARED_ORDER_BIT.toInt() -> {
                        preparedOrderHandler(page)
                    }
                }
            }
        }
    }

    private fun setUpRecycler() {
        binding.rlViewOrders.layoutManager = LinearLayoutManager(requireContext())
        adapter = OrderAdapter(orderArray, this@OrderFragment)
        binding.rlViewOrders.adapter = adapter
    }

    private fun initObservers() {
        viewModal.cafeStatus.observe(viewLifecycleOwner) {
            if (it.status.toBoolean()) {
                cafeSwitcher()
                cafeBtnChangeHandler()
            }
        }
        viewModal.showDialog.observe(viewLifecycleOwner) {

            if (it.toBoolean()) {
                sharedPreferencesManager.saveToken("")
                createDialog(requireContext(), getString(R.string.token_not_get_string))
                navigateToLogin()
            } else {
                binding.progress.visibility = View.GONE
                createDialog(requireContext(), it)
            }
        }

        viewModal.orderData.observe(viewLifecycleOwner) {
            if (it.data.isEmpty()) {
                binding.swipeRefreshLayout.visibility = View.GONE
            } else {
                binding.swipeRefreshLayout.visibility = View.VISIBLE
            }
            binding.swipeRefreshLayout.isRefreshing = false
            storeArray.clear()
            totalOrderCount = it.count
            storeArray.addAll(it.data)
            orderArray.addAll(it.data)
            progressVisibility(false)
            notifyDataSetChanged()
        }

        viewModal.cancelOrder.observe(viewLifecycleOwner) {
            createDialog(requireContext(), getString(R.string.cancel_order_string))
        }
    }

    private fun navigateToLogin() {
        findNavController().navigate(R.id.action_orderFragment_to_loginFragment)
    }

    private fun cafeBtnChangeHandler() {
        if (!sharedPreferencesManager.getIsCafeOpened()) {
            binding.apply {
                closedBtnHandler()
            }
        } else {
            openButtonHandler()
        }
    }

    private fun closedBtnHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_changebackground
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_change_background
            )

            openBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.white
                )
            )
        }
    }


    private fun openButtonHandler() {
        binding.apply {
            openBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.open_btn_default_background
            )
            closeBtn.background = ContextCompat.getDrawable(
                requireContext(),
                R.drawable.close_btn_default_background
            )
            openBtn.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            closeBtn.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.close_btn_color
                )
            )
        }
    }

    private fun cafeSwitcher() {
        if (sharedPreferencesManager.getIsCafeOpened()) {
            sharedPreferencesManager.saveIsCafeOpened(false)
        } else {
            sharedPreferencesManager.saveIsCafeOpened(true)
            createDialog(requireContext(), "Let's get started !! cafe is open now")
        }
    }

    private fun openCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.close_cafe_string),
            getString(R.string.close_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModal.switchCafe(Constants.CLOSE_BUTTON_BIT) {
                closedBtnHandler()

            }
        }
    }

    private fun closeCafe() {
        showConfirmationDialog(
            requireContext(),
            getString(R.string.open_cafe_string),
            getString(R.string.open_cafe_btn),
            getString(R.string.cancel)
        ) {
            viewModal.switchCafe(Constants.OPEN_BUTTON_BIT) {
                openButtonHandler()
            }

        }
    }


    private fun initClickListeners() {
        cafeBtnChangeHandler()
        binding.apply {
            newOrder.setOnClickListener {
                if (sharedPreferencesManager.getWhichOrderCategory() != Constants.NEW_ORDER_BIT.toInt()) {
                    searchBar.text?.clear()
                    page = 1
                    newOrderHandler(page)
                    sharedPreferencesManager.findWhichOrderCategory(Constants.NEW_ORDER_BIT.toInt())
                    orderArray.clear()
                }
            }
            prepared.setOnClickListener {
                if (sharedPreferencesManager.getWhichOrderCategory() != Constants.PREPARED_ORDER_BIT.toInt()) {
                    searchBar.text?.clear()
                    page = 1
                    preparedOrderHandler(page)
                    sharedPreferencesManager.findWhichOrderCategory(Constants.PREPARED_ORDER_BIT.toInt())
                    orderArray.clear()
                }
            }
            preparing.setOnClickListener {
                if (sharedPreferencesManager.getWhichOrderCategory() != Constants.PREPARING_ORDER_BIT.toInt()) {
                    searchBar.text?.clear()
                    page = 1
                    preparingOrderHandler(page)
                    sharedPreferencesManager.findWhichOrderCategory(Constants.PREPARING_ORDER_BIT.toInt())
                    orderArray.clear()
                }
            }
            openBtn.setOnClickListener {
                if (!sharedPreferencesManager.getIsCafeOpened()) {
                    closeCafe()
                }
            }
            closeBtn.setOnClickListener {
                if (sharedPreferencesManager.getIsCafeOpened()) {
                    openCafe()
                }
            }
        }
    }

    private fun preparingOrderHandler(page: Int) {
        progressVisibility(true)
        binding.apply {
            preparing.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.login_button_background)
            preparing.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            newOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            newOrder.setTextColor(ContextCompat.getColor(requireContext(), R.color.order_btn_color))
            prepared.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            prepared.setTextColor(ContextCompat.getColor(requireContext(), R.color.order_btn_color))
        }
        callApi(Constants.PREPARING_ORDER_BIT.toInt(), page)
    }

    private fun preparedOrderHandler(page: Int) {
        progressVisibility(true)
        binding.apply {
            prepared.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.login_button_background)
            prepared.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            newOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            newOrder.setTextColor(ContextCompat.getColor(requireContext(), R.color.order_btn_color))
            preparing.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            preparing.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.order_btn_color
                )
            )
        }
        token = sharedPreferencesManager.getToken()
        callApi(Constants.PREPARED_ORDER_BIT.toInt(), page)
    }

    private fun progressVisibility(b: Boolean) {
        binding.progress.isVisible = b
    }

    private fun newOrderHandler(page: Int) {
        binding.apply {
            progressVisibility(true)
            newOrder.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.login_button_background)
            newOrder.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            prepared.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            prepared.setTextColor(ContextCompat.getColor(requireContext(), R.color.order_btn_color))
            preparing.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.order_btn_background)
            preparing.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.order_btn_color
                )
            )
        }
        token = sharedPreferencesManager.getToken()
        callApi(Constants.NEW_ORDER_BIT.toInt(), page)
    }

    private fun callApi(i: Int, page: Int, search: String = "") {
        viewModal.getOrders(page, i, search)
    }

    override fun onResume() {
        super.onResume()
        token = sharedPreferencesManager.getToken()
        viewModal.getOrders(
            Constants.NEW_ORDER_BIT.toInt(),
            Constants.NEW_ORDER_BIT.toInt(),
            ""
        )
    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
        page = 1
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onItemClick(position: Int) {
        val directions =
            OrderFragmentDirections.actionOrderFragmentToOrderDetailFragment(orderArray[position])
        findNavController().navigate(directions)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun notifyDataSetChanged() {
        binding.rlViewOrders.adapter?.notifyDataSetChanged()
    }

    override fun cancelOrderItem(position: Int) {
        itemPosition = position
        showConfirmationDialog(
            requireContext(),
            getString(R.string.sure_message_cancel),
            getString(R.string.ok),
            getString(R.string.cancel)
        ) {
            itemPosition = position
            viewModal.cancelOrder(
                Constants.CANCEL_ORDER_BIT,
                orderArray[position].id.toString()
            ) {
                orderArray.removeAt(position)
                checkArrayEmpty()
                (binding.rlViewOrders.adapter as OrderAdapter).notifyItemRemoved(position)
            }
        }
    }

    override fun prepareOrder(position: Int) {
        itemPosition = position
        showConfirmationDialog(
            requireContext(),
            getString(R.string.sure_message_prepare),
            getString(R.string.ok),
            getString(R.string.cancel)
        ) {
            itemPosition = position
            viewModal.cancelOrder(
                Constants.PREPARING_ORDER_BIT,
                orderArray[position].id.toString()
            ) {
                orderArray.removeAt(position)
                page = 1
                checkArrayEmpty()
                (binding.rlViewOrders.adapter as OrderAdapter).notifyItemRemoved(position)
            }
        }
    }


    @SuppressLint("NotifyDataSetChanged")
    override fun removeOrder(position: Int) {
        binding.rlViewOrders.adapter?.notifyItemRemoved(position)
    }

    override fun deliveredOrder(position: Int) {
        itemPosition = position
        showConfirmationDialog(
            requireContext(),
            getString(R.string.sure_message_deliver),
            getString(R.string.ok),
            getString(R.string.cancel)
        ) {
            itemPosition = position
            viewModal.cancelOrder(
                Constants.DELIVERED_ORDER_BIT,
                orderArray[position].id.toString()
            ) {
                orderArray.removeAt(position)
                checkArrayEmpty()
                page = 1
                (binding.rlViewOrders.adapter as OrderAdapter).notifyItemRemoved(position)
            }
        }
    }


    private fun checkArrayEmpty(){
       if(orderArray.isEmpty()){
           binding.apply {
               noOrderFound.visibility = View.VISIBLE
               noOrderFoundText.visibility = View.VISIBLE
               noOrderFoundSubText.visibility = View.VISIBLE
               swipeRefreshLayout.visibility = View.GONE
           }
       }
    }
    override fun preparedOrder(position: Int) {
        itemPosition = position
        showConfirmationDialog(
            requireContext(),
            getString(R.string.sure_message_prepared),
            getString(R.string.ok),
            getString(R.string.cancel)
        ) {
            itemPosition = position
            viewModal.cancelOrder(
                Constants.PREPARED_ORDER_BIT,
                orderArray[position].id.toString()
            ) {
                orderArray.removeAt(position)
                page = 1
                checkArrayEmpty()
                (binding.rlViewOrders.adapter as OrderAdapter).notifyItemRemoved(position)
            }
        }
    }

}
