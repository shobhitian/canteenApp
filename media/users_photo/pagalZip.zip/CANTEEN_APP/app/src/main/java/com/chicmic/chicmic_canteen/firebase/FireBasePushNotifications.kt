package com.chicmic.chicmic_canteen.firebase


import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.ui.fragments.login.LoginFragment
import com.chicmic.chicmic_canteen.ui.fragments.order.OrderFragment
import com.chicmic.chicmic_canteen.utils.Constants
import com.chicmic.chicmic_canteen.utils.Constants.Companion.NOTIFY_ID
import com.chicmic.chicmic_canteen.utils.MyApp
import com.chicmic.chicmic_canteen.utils.MySharedPreferencesManager
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FireBasePushNotifications : FirebaseMessagingService() {

    private lateinit var sharedPreferencesManager: MySharedPreferencesManager



    override fun onNewToken(token: String) {
        super.onNewToken(token)
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(MyApp.getContext())
        sharedPreferencesManager.saveUserDeviceToken(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        sharedPreferencesManager = MySharedPreferencesManager.getInstance(MyApp.getContext())
        sendNotification(applicationContext, message)
    }

    fun getTokenAgain(){
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    return@OnCompleteListener
                }
                val token = task.result
                sharedPreferencesManager.saveUserDeviceToken(token)
            })
    }
    private fun sendNotification(context: Context, notificationMessage: RemoteMessage) {
        showMessageNotification(context, notificationMessage)
    }

    private fun showMessageNotification(context: Context, notificationMessage: RemoteMessage) {
        val notifyManager: NotificationManager?
        val pendingIntent: PendingIntent
        notifyManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            var mChannel = notifyManager.getNotificationChannel(Constants.ID)
            if (mChannel == null) {
                mChannel = NotificationChannel(Constants.ID, Constants.NAME, importance)
                mChannel.description = Constants.DESCRIPTION
                mChannel.enableVibration(true)
                mChannel.lightColor = Color.GREEN
                mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                notifyManager.createNotificationChannel(mChannel)
            }
        }


        val builder: NotificationCompat.Builder = NotificationCompat.Builder(context, Constants.ID)
        val intent = if (sharedPreferencesManager.getToken().toString().isEmpty()) {
            Intent(context, LoginFragment::class.java)
        } else {
            Intent(context, OrderFragment::class.java)
        }

        intent.putExtra(Constants.NAME, 3)

        pendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.getActivity(context, 10002, intent, PendingIntent.FLAG_MUTABLE)
        } else {
            PendingIntent.getActivity(context, 10002, intent, PendingIntent.FLAG_IMMUTABLE)
        }
        builder // required
            .setSmallIcon(R.drawable.chicmic_logo) // required
            .setContentTitle(getString(R.string.app_name))
            .setContentText(notificationMessage.notification?.body)
            .setDefaults(Notification.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val notification = builder.build()
        notifyManager.notify("1", NOTIFY_ID, notification)
    }

}