package com.chicmic.chicmic_canteen.modals.dashboard

data class ItemOrderRecordModals(
    val username: String,
    val orderTime: String,
    val orderItemList: ArrayList<OrderItemsList>
)

data class OrderItemsList(
    val count: Int,
    val itemName: String
)