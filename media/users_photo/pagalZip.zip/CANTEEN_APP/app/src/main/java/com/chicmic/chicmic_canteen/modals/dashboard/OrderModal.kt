package com.chicmic.chicmic_canteen.modals.dashboard

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize


data class OrderModal(
    val count: Int,
    val data: ArrayList<OrderItems>,
    val message: String,
    val status: Boolean,
    val response: String
)


@Parcelize
data class OrderModalArgs(
    val data: OrderItems
) : Parcelable

@Parcelize
data class SubProducts(
    val id: Int,
    val name: String,
    val description: String? = "",
    val image: String,
    val price: String,
    val status: Boolean,
    val stock: Boolean
) : Parcelable

@Parcelize
data class SubItems(
    val id: Int,
    val product: SubProducts,
    val quantity: Int,
    val order: Int
) : Parcelable

@Parcelize
data class OrderItems(
    val user: User,
    val id: Int,
    @SerializedName("total_amount")
    val totalAmount: Int,
    val description: String? = "",
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    val status: Int,
    val items: ArrayList<SubItems>,

    ) : Parcelable


@Parcelize
data class User(
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("last_name")
    val lastName: String,
    @SerializedName("user_profile")
    val userProfile: UserProfile?
) : Parcelable


@Parcelize
data class UserProfile(
    @SerializedName("year_of_joining")
    val joiningYear: Int? = 0,
    @SerializedName("emp_code")
    val empCode: String? = "N/A"
) : Parcelable

data class CancelOrder(
    val status: String
)

