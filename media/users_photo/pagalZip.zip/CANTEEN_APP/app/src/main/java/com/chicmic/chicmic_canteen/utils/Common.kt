package com.chicmic.chicmic_canteen.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.Resources
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.ui.activities.MainActivity
import com.google.android.gms.common.api.ApiException
import java.io.IOException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.*

fun showToast(context: Context, str: String) {
    Toast.makeText(context, str, Toast.LENGTH_SHORT).show()
}


/*This dialog is basically used as a information dialog*/
fun createDialog(context: Context, message: String, title: String = "Chicmic Seller") {
    val dialog = AlertDialog.Builder(context)
    dialog.apply {
        setCancelable(false)
        setIcon(R.drawable.splash_logo_icon)
        setTitle(title)
        setMessage(message)
        setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        setNegativeButton(null, null)
        val dialogInstance = dialog.create()
        dialogInstance.show()
    }
}

/* Provide us the custom dialog with options (it has been used as a confirmation dialog)*/
fun showConfirmationDialog(
    context: Context,
    msg: String,
    okButtonName: String,
    cancelButtonName: String,
    signOut: () -> Unit
) {
    val dialog = AlertDialog.Builder(context)
    dialog.apply {
        setCancelable(false)
        setMessage(msg)
        setIcon(R.drawable.splash_logo_icon)
        setTitle("Chicmic Seller")
        setPositiveButton(okButtonName) { dialog, _ ->
            dialog.dismiss()
            signOut()

        }
        setNegativeButton(cancelButtonName) { dialog, _ ->
            dialog.dismiss()
        }
        val dialogInstance = dialog.create()
        dialogInstance.show()
    }

}


fun showImageOptionDialog(
    context: Context,
    msg: String,
    okButtonName: String,
    cancelButtonName: String,
    cameraBtnClicked: () -> Unit,
    galleryBtnClicked:()->Unit
) {
    val dialog = AlertDialog.Builder(context)
    dialog.apply {
        setCancelable(true)
        setMessage(msg)
        setIcon(R.drawable.splash_logo_icon)
        setTitle(context.getString(R.string.chicmic_seller))
        setPositiveButton(okButtonName) { dialog, _ ->
            dialog.dismiss()
            cameraBtnClicked()

        }
        setNegativeButton(cancelButtonName) { dialog, _ ->
            dialog.dismiss()
            galleryBtnClicked()
        }
        val dialogInstance = dialog.create()
        dialogInstance.show()
    }

}

/* This function change the color of status bar */
@SuppressLint("ResourceType")
fun changeTopBarColor(context: Context, window: Window, color: Int) {
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
    window.statusBarColor = ContextCompat.getColor(context, color)
}

/* TO  remove the top bar from the screen basically it will remove the data from particular screens*/
fun removeActionBar(activity: Activity, context: Context) {
    (activity as MainActivity).apply {
        supportActionBar?.hide()
        setBottomVisibility(false)
    }
}

/* to verify internet connection */
@SuppressLint("ServiceCast")
fun isInternetAvailable(context: Context): Boolean {
    val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = connectivityManager.activeNetwork ?: return false
    val networkCapabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
    return networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/* Change and return the date into particular format*/
fun changeToRelevantFormat(createdAt: String, requiredFormat: String): CharSequence? {
    val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX", Locale.getDefault())
    val outputFormat = SimpleDateFormat(requiredFormat, Locale.getDefault())
    val date = inputFormat.parse(createdAt)
    return date?.let { outputFormat.format(it) }
}


/* for showing network exception to user */
fun getException(e: Exception): String {
    return when (e) {
        is ApiException -> {
            MyApp.getContext().getString(R.string.api_exception)
        }
        is UnknownHostException, is IOException -> {
            MyApp.getContext().getString(R.string.check_internet)
        }
        else -> {
            MyApp.getContext().getString(R.string.something_wrong)
        }
    }
}
