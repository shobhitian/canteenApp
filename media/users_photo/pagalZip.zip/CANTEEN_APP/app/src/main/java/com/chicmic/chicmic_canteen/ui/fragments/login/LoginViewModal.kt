package com.chicmic.chicmic_canteen.ui.fragments.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.chicmic.chicmic_canteen.R
import com.chicmic.chicmic_canteen.modals.Login
import com.chicmic.chicmic_canteen.modals.LoginResponse
import com.chicmic.chicmic_canteen.repository.SellerRepository
import com.chicmic.chicmic_canteen.utils.ResponseCodes
import com.chicmic.chicmic_canteen.utils.getException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {


    companion object {
        private const val TAG = "LOGIN_VIEW_MODAL"
        private val sellerRepository = SellerRepository()
    }


    private val _loginResponse: MutableLiveData<LoginResponse> = MutableLiveData()
    val loginResponse: LiveData<LoginResponse> get() = _loginResponse

    private val _showDialog: MutableLiveData<String> = MutableLiveData()
    val showDialog: LiveData<String> get() = _showDialog


    fun loginSeller(data: Login) {
        viewModelScope.launch{
            try {
                val response = sellerRepository.sellerLogin(data)
                if (response.isSuccessful)
                    response.body()?.let {
                        _loginResponse.postValue(it)
                    } else {
                    showResponse(response.code())
                }
            }catch (e: java.lang.Exception) {
                _showDialog.postValue(getException(e))
            }

        }
    }


    private fun showResponse(code: Int) {
        when (code) {
            ResponseCodes.KEY_400 -> {
                _showDialog.postValue(
                    getApplication<Application>().applicationContext.getString(
                        R.string.invalid_cred
                    )
                )
            }
            ResponseCodes.KEY_403 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.server_issue
                )
            )
            ResponseCodes.KEY_500 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.internal_server_error
                )
            )
            ResponseCodes.KEY_404 -> _showDialog.postValue(
                getApplication<Application>().applicationContext.getString(
                    R.string.page_not_found
                )
            )

        }
    }
}
